// 기본 모드: Supabase 익명 로그인 + 중계 함수(ai) 호출
import { SUPABASE_URL, SUPABASE_KEY } from './config.js';
import { db } from './db.js';

const AUTH = `${SUPABASE_URL}/auth/v1`;
const base = { apikey: SUPABASE_KEY, 'Content-Type': 'application/json' };

async function saveSession(s) {
  const sess = { access_token: s.access_token, refresh_token: s.refresh_token, expires_at: Date.now() + (s.expires_in || 3600) * 1000 };
  await db.setSetting('sb_session', JSON.stringify(sess));
  return sess;
}

async function authPost(path, body) {
  const res = await fetch(`${AUTH}${path}`, { method: 'POST', headers: base, body: JSON.stringify(body) });
  const j = await res.json().catch(() => ({}));
  if (!res.ok || !j.access_token) throw new Error(j.msg || j.error_description || j.message || `로그인 실패 (HTTP ${res.status})`);
  return saveSession(j);
}

async function getToken(force = false) {
  let s = null;
  try { s = JSON.parse((await db.getSetting('sb_session')) || 'null'); } catch {}
  if (s && !force && s.expires_at > Date.now() + 60_000) return s.access_token;
  if (s?.refresh_token) {
    try { return (await authPost('/token?grant_type=refresh_token', { refresh_token: s.refresh_token })).access_token; } catch {}
  }
  return (await authPost('/signup', { data: {} })).access_token; // 익명 사용자 새로 만들기
}

export class QuotaError extends Error {}

// OpenRouter chat/completions 응답 형식 + remaining 을 돌려준다
export async function serverChat(payload) {
  const call = async force => fetch(`${SUPABASE_URL}/functions/v1/ai`, {
    method: 'POST',
    headers: { ...base, Authorization: `Bearer ${await getToken(force)}` },
    body: JSON.stringify(payload),
  });
  let res = await call(false);
  if (res.status === 401) res = await call(true); // 토큰 만료 등 → 한 번 새로 받아서 재시도
  const data = await res.json().catch(() => ({}));
  if (typeof data.remaining === 'number') await db.setSetting('sb_remaining', JSON.stringify({ day: new Date().toLocaleDateString('sv-SE'), n: data.remaining }));
  if (res.status === 429) {
    await db.setSetting('sb_remaining', JSON.stringify({ day: new Date().toLocaleDateString('sv-SE'), n: 0 }));
    throw new QuotaError('오늘 무료로 쓸 수 있는 횟수를 다 썼어요. 내일 0시에 다시 차요.\n지금 더 쓰려면 내 API 키를 넣어 주세요.');
  }
  if (!res.ok) throw new Error(data.error?.message || `서버 오류 (HTTP ${res.status})`);
  return data;
}

// 오늘 남은 횟수 (마지막으로 받은 값, 모르면 null)
export async function remainingToday() {
  try {
    const r = JSON.parse((await db.getSetting('sb_remaining')) || 'null');
    return r && r.day === new Date().toLocaleDateString('sv-SE') ? r.n : null;
  } catch { return null; }
}
