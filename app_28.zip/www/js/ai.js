// AI 호출: 사용자의 말/사진을 workout_logs 형식으로 정형화
// OpenAI 와 OpenRouter 둘 다 같은 형식(chat/completions)을 쓴다

import { serverChat } from './server.js';

export const PROVIDERS = {
  server: { label: '기본 (앱 제공, 무료)', base: '', keyPrefix: '', defaultModel: '' },
  openai: {
    label: 'OpenAI (ChatGPT)', base: 'https://api.openai.com/v1', keyPrefix: 'sk-',
    keyUrl: 'platform.openai.com/api-keys', defaultModel: 'gpt-4.1-mini',
  },
  openrouter: {
    label: 'OpenRouter', base: 'https://openrouter.ai/api/v1', keyPrefix: 'sk-or-',
    keyUrl: 'openrouter.ai/keys', defaultModel: '',
  },
};

function headers(provider, apiKey) {
  const h = { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` };
  if (provider === 'openrouter') { h['HTTP-Referer'] = 'https://workoutlog.app'; h['X-Title'] = 'Caldron AI'; }
  return h;
}

export async function validateKey(provider, apiKey) {
  const p = PROVIDERS[provider];
  const url = provider === 'openrouter' ? `${p.base}/key` : `${p.base}/models`;
  const res = await fetch(url, { headers: headers(provider, apiKey) });
  if (res.status === 401 || res.status === 403) throw new Error('API 키가 올바르지 않습니다.');
  if (!res.ok) throw new Error(`확인 실패 (HTTP ${res.status})`);
  return true;
}

export function usableModelId(id) {
  const tag = String(id || '').split(':')[1];
  return !tag || tag === 'free';
}

// OpenRouter: 사진을 읽을 수 있는 모델 목록 (가격 포함)
export async function listVisionModels() {
  const res = await fetch(`${PROVIDERS.openrouter.base}/models`);
  if (!res.ok) throw new Error(`모델 목록을 못 받았어요 (HTTP ${res.status})`);
  const { data = [] } = await res.json();
  return data
    // 일반 대화(chat/completions)로 쓸 수 없는 변형(:batch 등)은 뺀다. :free 는 남김
    .filter(m => usableModelId(m.id))
    .filter(m => (m.architecture?.input_modalities || []).includes('image') && (m.architecture?.output_modalities || ['text']).includes('text'))
    .map(m => {
      const inP = Number(m.pricing?.prompt || 0) * 1e6, outP = Number(m.pricing?.completion || 0) * 1e6;
      return { id: m.id, name: m.name || m.id, free: inP === 0 && outP === 0, inP, outP };
    })
    .sort((x, y) => (x.free === y.free ? x.inP - y.inP : x.free ? -1 : 1));
}

// 기본 모델 고르기: 사진 잘 읽고 저렴한 계열 우선, 없으면 가장 싼 유료 모델
export function pickDefaultModel(models) {
  const paid = models.filter(m => !m.free);
  for (const re of [/gemini.*flash(?!.*lite)/i, /gpt.*mini/i, /claude.*haiku/i, /gemini/i]) {
    const hit = paid.find(m => re.test(m.id));
    if (hit) return hit.id;
  }
  return (paid[0] || models[0] || {}).id || '';
}

function systemPrompt({ today, types, names, recent = '' }) {
  return `너는 운동 기록 앱의 기록 도우미다. 사용자의 말에서 운동 기록을 추출해 JSON으로만 답한다.
오늘 날짜: ${today} (Asia/Seoul). "어제", "지난 토요일" 같은 표현은 이 날짜 기준으로 계산한다.

[기존 운동종류(exercise_type)] ${types.length ? types.join(', ') : '(아직 없음)'}
[기존 세부운동(exercise_name)] ${names.length ? names.join(', ') : '(아직 없음)'}
[최근 기록 (최신순)]
${recent || '(아직 없음)'}

규칙
- 가능한 한 기존 운동종류/세부운동 이름을 그대로 재사용한다. 표기만 다른 경우(예: 런닝→러닝) 기존 이름으로 맞춘다.
- 기존 운동종류에 맞지 않으면 새 운동종류 이름을 짧게 정하고 is_new_type=true 로 표시하며, 가장 가까운 기존 종류를 candidates 에 최대 3개 넣는다.
- 헬스처럼 한 번에 여러 세부운동을 하면 세부운동마다 records 하나씩 만든다.
- 클라이밍의 exercise_name 은 지점·지역명을 뺀 암장 브랜드 이름으로 한다 (예: "더클라임 성수점" → "더클라임", "알레클라임 혜화" → "알레클라임"). 기존 세부운동에 같은 암장이 있으면 그 이름을 그대로 쓴다. 지점까지 포함한 전체 이름은 detail_json.gym 에 넣는다.
- duration_min 은 분 단위 숫자. 모르면 null.
- result_summary 는 대표 결과를 20자 이내로 직접 만든다 (예: "5km 무휴식", "20kg 6/5/4회", "파랑4 빨강2").
- memo 는 사용자의 느낌/컨디션 표현만 담는다. 없으면 null.
- detail_json 은 종목별 세부정보. 숫자는 숫자 타입으로, 모르는 값은 넣지 않는다. 같은 운동종류는 항상 같은 키 이름을 쓴다.
  러닝 예: {"distance_km":5.0,"pace_sec_per_km":408,"avg_heart_rate":168,"max_heart_rate":181,"cadence":155,"continuous":true}
  헬스 예: {"sets":[{"weight_kg":20,"reps":6},{"weight_kg":20,"reps":5}],"assistance":null}
  클라이밍 예: {"gym":"더클라임 성수","problems":{"blue":4,"red":2}} (exercise_name 은 "더클라임")
  새 종목·새 방식의 운동은 예시에 없어도 네가 판단해서 숫자로 비교 가능한 키(영문 snake_case)를 만든다. 같은 세부운동의 [최근 기록]에 쓰인 키 이름이 있으면 그대로 재사용한다.
- 운동이 여러 부분으로 나뉘면 (빠르게/천천히 반복, 워밍업·본운동·쿨다운, 랩, 라운드 등) detail_json.segments 에 순서대로 모두 넣는다:
  [{"label":"달리기","kind":"work","distance_km":0.6,"pace_sec_per_km":292}, {"label":"걷기","kind":"rest","distance_km":0.8,"pace_sec_per_km":620}, ...]
  kind 는 work(실제 성과 구간) 또는 rest(회복·휴식·워밍업·쿨다운). 구간 숫자 키도 위와 같은 이름 규칙을 쓴다. 그래프에서 어림한 값이면 detail_json.estimated=true.
- 대표 성과는 회복·휴식을 빼고 계산해 detail_json 최상위에 둔다 (예: 걷기가 섞인 러닝이면 work 구간만의 평균 페이스·최고 페이스·반복 횟수). 이 운동의 실력을 가장 잘 보여 주는 값이 무엇인지 네가 판단한다.
- detail_json._chart 에 대시보드 힌트를 준다 (키 이름 목록):
  {"main":[이 운동의 실력을 보여 주는 대표 키, 중요한 순],"lower_is_better":[작을수록 좋은 키 (페이스·기록 시간 등)],"hide":[추세 차트에 넣으면 왜곡되는 키 (예: 걷기가 섞인 전체 평균 페이스)]}
- reply 의 비교도 같은 성격의 기록끼리, 대표 키로 한다 (예: 인터벌은 이전 인터벌의 work 구간 페이스와 비교하고, 일반 러닝 평균과 비교하지 않는다).
- 페이스 "6분48초" → 408 처럼 초로 변환한다.
- 사진이 첨부되면 러닝앱(나이키런, 스트라바, 가민, 애플워치 등)이나 클라이밍 앱/기록 공유 이미지다. 사진에 보이는 숫자를 그대로 읽어 기록한다:
  거리, 시간, 평균 페이스, 심박(평균/최대), 케이던스, 고도(elevation_gain_m), 칼로리(calories), 날짜, 장소/암장 이름, 난이도 색깔·그레이드별 완등 수 등.
  사진에 날짜가 보이면 그 날짜를 쓰고, 없으면 오늘로 한다. 시간 "34:12" 는 34.2분. 잘 안 보이는 값은 지어내지 말고 넣지 않는다.
  여러 장이면 같은 운동이면 합치고, 다른 운동이면 각각 records 로 만든다.
- intent="log" 일 때 reply 는 운동을 같이 챙겨 주는 친근한 코치처럼 2~4문장으로 쓴다 (존댓말 "~요" 체, 따뜻하지만 과장 없이):
  1) 오늘 한 운동을 구체적인 숫자로 짚어 칭찬한다 (예: "5km를 쉬지 않고 34분에 완주하셨네요!").
  2) [최근 기록]에 같은 운동이 있으면 비교한다: 페이스·거리·무게·횟수·완등 수가 좋아졌으면 얼마나 좋아졌는지, 비슷하면 꾸준함을, 떨어졌으면 컨디션 탓일 수 있다고 부드럽게. 이번 주 몇 번째인지, 며칠 만에 다시 했는지도 좋다.
  3) 사용자가 말한 느낌(memo)에 공감하거나, 다음에 해 볼 만한 짧은 팁을 하나 덧붙인다 (선택).
  최근 기록이 없으면 첫 기록을 반겨 준다. 기록에 없는 비교·숫자는 지어내지 않는다. 이모지는 넣지 않거나 1개까지. "N건 기록했어요" 같은 말은 앱이 따로 보여 주니 쓰지 않는다.
  사진이면 읽은 핵심 수치를 자연스럽게 문장에 녹인다.
- 운동 기록이 아닌 말이면 intent="other", 운동 이야기지만 정보가 부족하면 intent="clarify" 로 하고 reply 에 짧게 되묻는다.
  (종목과 날짜만 알면 기록 가능. 나머지는 없어도 된다.)

출력 형식 (JSON만):
{
  "intent": "log" | "clarify" | "other",
  "reply": "사용자에게 보여줄 한국어 답변 (log면 위 규칙대로 2~4문장)",
  "records": [
    {
      "date": "YYYY-MM-DD",
      "exercise_type": "러닝",
      "is_new_type": false,
      "candidates": [],
      "exercise_name": "야외 러닝",
      "duration_min": 34,
      "result_summary": "5km 무휴식",
      "detail_json": {},
      "memo": null
    }
  ]
}`;
}

// 사진 → 긴 변 1600px JPEG data URL (전송량 줄이기)
// 안드로이드 WebView는 기종·사진 종류에 따라 한 방법이 실패할 수 있어 여러 방법을 차례로 시도한다.
const MAX_SIDE = 1600;
const readAsDataUrl = file => new Promise((ok, bad) => {
  const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = () => bad(r.error || new Error('파일 읽기 실패')); r.readAsDataURL(file);
});
const loadImg = src => new Promise((ok, bad) => {
  const i = new Image(); i.onload = () => ok(i); i.onerror = () => bad(new Error('이미지 해석 실패')); i.src = src;
});
function drawScaled(src, w, h) {
  const scale = Math.min(1, MAX_SIDE / Math.max(w, h));
  const cv = document.createElement('canvas');
  cv.width = Math.max(1, Math.round(w * scale)); cv.height = Math.max(1, Math.round(h * scale));
  const ctx = cv.getContext('2d');
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, cv.width, cv.height); // 투명 PNG → 흰 배경
  ctx.drawImage(src, 0, 0, cv.width, cv.height);
  const out = cv.toDataURL('image/jpeg', 0.85);
  if (!out.startsWith('data:image/jpeg')) throw new Error('캔버스 변환 실패');
  return out;
}

// HEIC/HEIF(갤럭시 '고효율 사진', 아이폰 기본) 판별: 형식 이름 또는 파일 앞부분(ftypheic 등)
async function looksHeic(file) {
  if (/hei[cf]/i.test(file.type) || /\.hei[cf]$/i.test(file.name || '')) return true;
  try {
    const h = new TextDecoder('latin1').decode(new Uint8Array(await file.slice(0, 16).arrayBuffer()));
    return h.slice(4, 8) === 'ftyp' && /^(heic|heix|heim|heis|hevc|hevx|mif1|msf1)/.test(h.slice(8, 12));
  } catch { return false; }
}
// 변환 라이브러리는 HEIC 사진이 들어왔을 때만 불러온다 (앱에 포함된 파일 → 없으면 CDN)
let heicLib = null;
function loadHeicLib() {
  if (window.heic2any) return Promise.resolve(window.heic2any);
  if (heicLib) return heicLib;
  const srcs = ['vendor/heic2any.min.js', 'https://cdn.jsdelivr.net/npm/heic2any@0.0.4/dist/heic2any.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/heic2any/0.0.4/heic2any.min.js'];
  heicLib = (async () => {
    for (const src of srcs) {
      try {
        await new Promise((ok, bad) => { const s = document.createElement('script'); s.src = src; s.onload = ok; s.onerror = bad; document.head.appendChild(s); });
        if (window.heic2any) return window.heic2any;
      } catch {}
    }
    heicLib = null;
    throw new Error('HEIC 변환 도구를 불러오지 못했어요 (인터넷 연결 확인)');
  })();
  return heicLib;
}
async function heicToJpeg(file) {
  const conv = await loadHeicLib();
  const out = await conv({ blob: file, toType: 'image/jpeg', quality: 0.85 });
  const blob = Array.isArray(out) ? out[0] : out;
  return new File([blob], (file.name || 'photo').replace(/\.\w+$/, '') + '.jpg', { type: 'image/jpeg' });
}

async function toDataUrl(file, isRetry = false) {
  const tried = [];
  const isHeic = !isRetry && await looksHeic(file);
  // 0) HEIC는 먼저 JPEG로 바꾼 뒤 아래 과정으로 (기기가 직접 읽을 수 있으면 그것도 OK)
  if (isHeic) {
    try { return await toDataUrl(await heicToJpeg(file), true); }
    catch (e) { tried.push('heic:' + (e?.message || e)); }
  }
  // 1) createImageBitmap (메모리 적게, 큰 사진에 강함)
  if (window.createImageBitmap) {
    try {
      const bmp = await createImageBitmap(file);
      try { return drawScaled(bmp, bmp.width, bmp.height); } finally { bmp.close?.(); }
    } catch (e) { tried.push('bitmap:' + (e?.message || e)); }
  }
  // 2) FileReader → <img> (blob 주소가 막힌 WebView 대비)
  try {
    const dataUrl = await readAsDataUrl(file);
    const img = await loadImg(dataUrl);
    return drawScaled(img, img.naturalWidth, img.naturalHeight);
  } catch (e) { tried.push('img:' + (e?.message || e)); }
  console.warn('toDataUrl failed', file.type, file.size, tried);
  const info = `${file.type || '형식 모름'}, ${Math.round(file.size / 1024)}KB`;
  throw new Error(`사진을 열 수 없어요. 스크린샷이나 JPG·PNG 사진으로 다시 올려 주세요. (${info} / ${tried.join(' / ')})`);
}

export async function parseWorkout({ provider = 'openai', apiKey, model, history, text, today, types, names, recent = '', images = [] }) {
  const urls = images.length ? await Promise.all(images.map(toDataUrl)) : [];
  // 기본(서버) 모드: 지시문은 서버가 붙인다. 앱은 재료만 보낸다
  if (provider === 'server') {
    const data = await serverChat({ text, images: urls, today, types, names, recent,
      history: history.slice(-8).filter(m => typeof m.content === 'string') });
    const out = parseContent(data.choices?.[0]?.message?.content);
    out.remaining = data.remaining;
    return out;
  }
  // 내 API 키 모드: 내 키로 직접 호출하므로 지시문도 앱에서 붙인다
  let userContent = text;
  if (urls.length) {
    userContent = [{ type: 'text', text }, ...urls.map(u => ({ type: 'image_url', image_url: { url: u, detail: 'high' } }))];
  }
  const messages = [
    { role: 'system', content: systemPrompt({ today, types, names, recent }) },
    ...history.slice(-8),
    { role: 'user', content: userContent },
  ];
  if (!model) throw new Error('설정 탭에서 모델을 먼저 골라 주세요.');
  const url = `${PROVIDERS[provider].base}/chat/completions`;
  const call = jsonMode => fetch(url, {
    method: 'POST', headers: headers(provider, apiKey),
    body: JSON.stringify({ model, messages, ...(jsonMode ? { response_format: { type: 'json_object' } } : {}) }),
  });
  let res = await call(true);
  if (res.status === 400) res = await call(false); // JSON 모드를 지원하지 않는 모델
  if (!res.ok) {
    let msg = `HTTP ${res.status}`;
    try { const j = await res.json(); msg = j.error?.message || msg; } catch {}
    if (res.status === 402) msg = '크레딧이 부족해요. 충전하거나 무료 모델을 골라 주세요.';
    if (res.status === 429) {
      const raw = msg;
      if (/per-day|per day/i.test(raw)) msg = '오늘 무료 모델 하루 한도를 다 썼어요. 내일 오전 9시에 다시 차요. 그 전에 쓰려면 설정에서 유료 모델로 바꿔 주세요.';
      else if (/per-min|per minute/i.test(raw)) msg = '1분에 보낼 수 있는 횟수를 넘었어요. 1분 뒤에 다시 보내 주세요.';
      else msg = '지금 이 무료 모델을 쓰는 사람이 많아서 막혔어요 (내 한도와는 별개). 잠시 후 다시 보내거나 설정에서 다른 모델로 바꿔 주세요.';
      msg += `\n(원문: ${raw})`;
    }
    throw new Error(msg);
  }
  const data = await res.json();
  if (data.error) throw new Error(data.error.message || '모델 오류');
  return parseContent(data.choices?.[0]?.message?.content);
}

function parseContent(content = '{}') {
  let out;
  try { out = JSON.parse(content || '{}'); }
  catch {
    const m = String(content).match(/\{[\s\S]*\}/); // 앞뒤 설명이 붙은 경우
    try { out = JSON.parse(m ? m[0] : ''); } catch { throw new Error('응답을 해석하지 못했습니다. 다시 보내 주세요.'); }
  }
  out.records = Array.isArray(out.records) ? out.records : [];
  return out;
}
