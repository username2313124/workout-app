// Caldron AI → AI 중계 함수 (Google Gemini)
// 앱은 사용자 말·사진·기존 기록만 보내고, AI 지시문(시스템 프롬프트)은 이 서버가 붙인다.
// → 남이 키를 가져가도 '운동 기록 추출' 외 용도로 쓸 수 없음
// 필요한 비밀값(Edge Functions → Secrets): GEMINI_API_KEY (Google AI Studio 키)
// 선택: GEMINI_MODEL (기본 gemini-3.8-flash,gemini-3.5-flash-lite). 쉼표로 여러 개 적으면 앞에서부터 시도 (예: 모델A,모델B)
// 선택: GEMINI_REASONING (기본 low). 답하기 전 '생각' 정도: none(가장 빠름) / low / medium / high / default(모델 기본값, 안 보냄)
// 선택: DAILY_LIMIT (기본 10)
import { createClient } from 'npm:@supabase/supabase-js@2';

const DAILY_LIMIT = Number(Deno.env.get('DAILY_LIMIT') ?? '10');
const GEMINI_KEY = Deno.env.get('GEMINI_API_KEY') || '';
const GEMINI_MODELS = (Deno.env.get('GEMINI_MODEL') || 'gemini-3.8-flash,gemini-3.5-flash-lite').split(',').map(x => x.trim()).filter(Boolean);
const GEMINI_REASONING = (Deno.env.get('GEMINI_REASONING') || 'low').trim().toLowerCase();
const GEMINI_URL ='https://generativelanguage.googleapis.com/v1beta/openai/chat/completions'; // OpenAI 호환 형식
const MAX_IMAGES = 4;
const MAX_BODY = 8 * 1024 * 1024; // 8MB

function systemPrompt({ today, types, names, recent }: { today: string; types: string[]; names: string[]; recent: string }) {
  return `너는 운동 기록 앱의 기록 도우미다. 사용자의 말에서 운동 기록을 추출해 JSON으로만 답한다.
오늘 날짜: ${today} (Asia/Seoul). "어제", "지난 토요일" 같은 표현은 이 날짜 기준으로 계산한다.

[기존 운동종류(exercise_type)] ${types.length ? types.join(', ') : '(아직 없음)'}
[기존 세부운동(exercise_name)] ${names.length ? names.join(', ') : '(아직 없음)'}
[최근 기록 (최신순)]
${recent || '(아직 없음)'}

규칙
- 가능한 한 기존 운동종류/세부운동 이름을 그대로 재사용한다. 표기만 다른 경우(예: 런닝→러닝) 기존 이름으로 맞춘다.
- 기존 운동종류에 맞지 않으면 새 운동종류 이름을 짧게 정하고 is_new_type=true 로 표시하며, 가장 가까운 기존 종류를 candidates 에 최대 3개 넣는다.
- 헬스처럼 한 번에 여러 세부운동을 하면 세부운동마다 records 하나씩 만든다. 운동일지·PT일지 사진 한 장에 세부운동이 6개 있으면 records 도 6개다.
  여러 세부운동을 한 record 로 합치거나 "OO 외 5종", "6종 세트 완료" 처럼 묶어서 요약하지 않는다. 각 record 의 detail_json.sets 에 그 세부운동의 세트별 무게·횟수를 모두 넣는다.
  같은 날 같은 운동일지의 세부운동들은 date·duration_min 이 같아도 된다 (전체 시간만 적혀 있으면 각 record 에 같은 값을 넣는다). 일지에 적힌 운동 부위(예: <등>, <가슴,어깨>)는 detail_json.target 에 넣는다.
- 클라이밍의 exercise_name 은 지점·지역명을 뺀 암장 브랜드 이름으로 한다 (예: "더클라임 성수점" → "더클라임", "알레클라임 혜화" → "알레클라임"). 기존 세부운동에 같은 암장이 있으면 그 이름을 그대로 쓴다. 지점까지 포함한 전체 이름은 detail_json.gym 에 넣는다.
- duration_min 은 분 단위 숫자. 모르면 null.
- result_summary 는 대표 결과를 20자 이내로 직접 만든다 (예: "5km 무휴식", "20kg 6/5/4회", "파랑4 빨강2").
- memo 는 사용자의 느낌/컨디션 표현만 담는다. 없으면 null.
- detail_json 은 종목별 세부정보. 숫자는 숫자 타입으로, 모르는 값은 넣지 않는다. 같은 운동종류는 항상 같은 키 이름을 쓴다.
  러닝 예: {"distance_km":5.0,"pace_sec_per_km":408,"avg_heart_rate":168,"max_heart_rate":181,"cadence":155,"continuous":true}
  헬스 예: {"sets":[{"weight_kg":20,"reps":6},{"weight_kg":20,"reps":5}],"assistance":null}
  클라이밍 예: {"gym":"더클라임 성수","problems":{"blue":4,"red":2}} (exercise_name 은 "더클라임")
  새 종목·새 방식의 운동은 예시에 없어도 네가 판단해서 숫자로 비교 가능한 키(영문 snake_case)를 만든다. 같은 세부운동의 [최근 기록]에 쓰인 키 이름이 있으면 그대로 재사용한다. ([최근 기록]에는 구간 목록이 생략되어 보이니, 최근 기록에 segments 가 안 보여도 구간이 있는 운동이면 segments 를 넣는다.)
- 운동이 여러 부분으로 나뉘면 (빠르게/천천히 반복, 워밍업·본운동·쿨다운, 랩, 라운드 등) detail_json.segments 에 순서대로 모두 넣는다:
  [{"label":"달리기","kind":"work","distance_km":0.6,"pace_sec_per_km":292}, {"label":"걷기","kind":"rest","distance_km":0.8,"pace_sec_per_km":620}, ...]
  kind 는 work(실제 성과 구간) 또는 rest(회복·휴식·워밍업·쿨다운). 구간 숫자 키도 위와 같은 이름 규칙을 쓴다. 그래프에서 어림한 값이면 detail_json.estimated=true.
  구간 표가 없고 페이스·속도 그래프만 있어도, 그래프에서 빠른 구간과 느린 구간이 번갈아 보이면 x축 거리와 y축 페이스를 읽어 segments 를 반드시 만든다 (각 구간에 distance_km 와 pace_sec_per_km 필수). 대표 값만 넣고 segments 를 빼지 않는다.
- 대표 성과는 회복·휴식을 빼고 계산해 detail_json 최상위에 둔다 (예: 걷기가 섞인 러닝이면 work 구간만의 평균 페이스·최고 페이스·반복 횟수). 이 운동의 실력을 가장 잘 보여 주는 값이 무엇인지 네가 판단한다.
- detail_json._chart 에 대시보드 힌트를 준다 (키 이름 목록):
  {"main":[이 운동의 실력을 보여 주는 대표 키, 중요한 순],"lower_is_better":[작을수록 좋은 키 (페이스·기록 시간 등)],"hide":[추세 차트에 넣으면 왜곡되는 키 (예: 걷기가 섞인 전체 평균 페이스)]}
- reply 의 비교도 같은 성격의 기록끼리, 대표 키로 한다 (예: 인터벌은 이전 인터벌의 work 구간 페이스와 비교하고, 일반 러닝 평균과 비교하지 않는다).
- 페이스 "6분48초" → 408 처럼 초로 변환한다.
- 사진이 첨부되면 러닝앱(나이키런, 스트라바, 가민, 애플워치 등)이나 클라이밍 앱/기록 공유 이미지다. 사진에 보이는 숫자를 그대로 읽어 기록한다:
  거리, 시간, 평균 페이스, 심박(평균/최대), 케이던스, 고도(elevation_gain_m), 칼로리(calories), 날짜, 장소/암장 이름, 난이도 색깔·그레이드별 완등 수 등.
  사진에 날짜가 보이면 그 날짜를 쓰고, 없으면 오늘로 한다. 시간 "34:12" 는 34.2분. 잘 안 보이는 값은 지어내지 말고 넣지 않는다.
  여러 장이면: 같은 한 번의 운동을 여러 화면으로 찍은 것(예: 러닝 요약 화면 + 그래프 화면)이면 합치고, 날짜가 다르거나 다른 운동이면 각각 records 로 만든다. 사진마다 날짜를 따로 읽는다.
- intent="log" 일 때 reply 는 운동을 같이 챙겨 주는 친근한 코치처럼 2~4문장으로 쓴다 (존댓말 "~요" 체, 따뜻하지만 과장 없이):
  1) 오늘 한 운동을 구체적인 숫자로 짚어 칭찬한다 (예: "5km를 쉬지 않고 34분에 완주하셨네요!").
  2) [최근 기록]에 같은 운동이 있으면 비교한다: 페이스·거리·무게·횟수·완등 수가 좋아졌으면 얼마나 좋아졌는지, 비슷하면 꾸준함을, 떨어졌으면 컨디션 탓일 수 있다고 부드럽게. 이번 주 몇 번째인지, 며칠 만에 다시 했는지도 좋다.
  3) 사용자가 말한 느낌(memo)에 공감하거나, 다음에 해 볼 만한 짧은 팁을 하나 덧붙인다 (선택).
  최근 기록이 없으면 첫 기록을 반겨 준다. 기록에 없는 비교·숫자는 지어내지 않는다. 이모지는 넣지 않거나 1개까지. "N건 기록했어요" 같은 말은 앱이 따로 보여 주니 쓰지 않는다.
  사진이면 읽은 핵심 수치를 자연스럽게 문장에 녹인다.
- 운동 기록이 아닌 말이면 intent="other", 운동 이야기지만 정보가 부족하면 intent="clarify" 로 하고 reply 에 짧게 되묻는다.
  (종목과 날짜만 알면 기록 가능. 나머지는 없어도 된다.)

출력 형식 (JSON만):
{
  "intent": "log" | "clarify" | "other",
  "reply": "사용자에게 보여줄 한국어 답변 (log면 위 규칙대로 2~4문장)",
  "records": [
    {
      "date": "YYYY-MM-DD",
      "exercise_type": "러닝",
      "is_new_type": false,
      "candidates": [],
      "exercise_name": "야외 러닝",
      "duration_min": 34,
      "result_summary": "5km 무휴식",
      "detail_json": {},
      "memo": null
    }
  ]
}`;
}

// 앱이 보낸 값 검사·정리 (길이 제한으로 남용 차단)
const str = (v: unknown, max: number) => (typeof v === 'string' ? v : '').slice(0, max);
const strList = (v: unknown, n: number, max: number) => (Array.isArray(v) ? v : []).filter(x => typeof x === 'string').slice(0, n).map(x => x.slice(0, max));
function buildMessages(body: any) {
  const text = str(body.text, 2000).trim();
  const images = (Array.isArray(body.images) ? body.images : [])
    .filter((u: unknown) => typeof u === 'string' && /^data:image\/(jpeg|png|webp);base64,/.test(u as string));
  if (!text && !images.length) throw new Error('보낼 내용이 없어요');
  if (images.length > MAX_IMAGES) throw new Error(`사진은 한 번에 ${MAX_IMAGES}장까지예요`);
  const today = /^\d{4}-\d{2}-\d{2}$/.test(body.today) ? body.today : new Date().toLocaleDateString('sv-SE', { timeZone: 'Asia/Seoul' });
  const history = (Array.isArray(body.history) ? body.history : [])
    .filter((m: any) => (m?.role === 'user' || m?.role === 'assistant') && typeof m.content === 'string')
    .slice(-8).map((m: any) => ({ role: m.role, content: m.content.slice(0, 1500) }));
  const userContent = images.length
    ? [{ type: 'text', text: text || '이 사진의 운동 기록을 분석해서 기록해줘' }, ...images.map((u: string) => ({ type: 'image_url', image_url: { url: u, detail: 'high' } }))]
    : text;
  return [
    { role: 'system', content: systemPrompt({ today, types: strList(body.types, 100, 40), names: strList(body.names, 200, 40), recent: str(body.recent, 8000) }) },
    ...history,
    { role: 'user', content: userContent },
  ];
}

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });
const fail = (status: number, message: string, extra = {}) => json({ error: { message }, ...extra }, status);

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return fail(405, 'POST만 받아요');

  const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

  // 1) 누가 보냈는지 확인 (익명 로그인 토큰)
  const token = (req.headers.get('Authorization') ?? '').replace(/^Bearer\s+/i, '');
  const { data: { user } } = await admin.auth.getUser(token);
  if (!user) return fail(401, '로그인이 필요해요');

  // 2) 요청 크기·사진 장수 확인
  const raw = await req.text();
  if (raw.length > MAX_BODY) return fail(413, '사진이 너무 커요');
  let body: any;
  try { body = JSON.parse(raw); } catch { return fail(400, '잘못된 요청이에요'); }
  if (Array.isArray(body?.messages)) return fail(426, '앱이 예전 버전이에요. 앱을 새로고침하거나 업데이트해 주세요.');
  let messages;
  try { messages = buildMessages(body); } catch (e) { return fail(400, (e as Error).message); }

  // 3) 하루 한도 차감
  const { data: used, error: qErr } = await admin.rpc('use_ai_quota', { p_user: user.id, p_limit: DAILY_LIMIT });
  if (qErr) return fail(500, '사용량 확인 실패: ' + qErr.message);
  if (used === null) return fail(429, `free-models-per-day: 오늘 쓸 수 있는 ${DAILY_LIMIT}회를 다 썼어요. 내일 0시에 다시 차요.`, { remaining: 0 });

  // 4) Gemini 모델을 앞에서부터 시도 (한도 초과·오류면 다음 모델)
  let lastStatus = 0, lastMsg = '';
  const hasImages = messages.some((m: any) => Array.isArray(m.content));
  if (!GEMINI_KEY) { await admin.rpc('refund_ai_quota', { p_user: user.id }); return fail(500, '서버 설정 오류: GEMINI_API_KEY가 없어요'); }
  const list = GEMINI_MODELS;
  let last: any = null; // 사진 재시도 끝에 남은 마지막 정상 응답
  for (const [i, model] of list.entries()) {
    const useReasoning = GEMINI_REASONING !== 'default' && GEMINI_REASONING !== '';
    const call = (jsonMode: boolean, reasoning: boolean) => fetch(GEMINI_URL, {
      method: 'POST',
      headers: { Authorization: `Bearer ${GEMINI_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model, messages, // 토큰 제한 없음: 무료 모델은 횟수로만 제한됨
        ...(jsonMode ? { response_format: { type: 'json_object' } } : {}),
        ...(reasoning ? { reasoning_effort: GEMINI_REASONING } : {}), // 생각을 줄여 속도 ↑
      }),
    });
    let res: Response;
    try {
      res = await call(true, useReasoning);
      // 400이면 모델이 지원 안 하는 옵션 → 생각 설정 빼고, 그래도 안 되면 JSON 모드까지 빼고 재시도
      if (res.status === 400 && useReasoning) res = await call(true, false);
      if (res.status === 400) res = await call(false, false);
    } catch (e) { lastStatus = 502; lastMsg = (e as Error).message; continue; }

    const raw = await res.json().catch(() => ({}));
    const data = Array.isArray(raw) ? raw[0] ?? {} : raw; // Gemini 오류는 배열로 올 때가 있음
    await admin.from('ai_logs').insert({
      user_id: user.id, model: `gemini/${model}`, status: res.status,
      prompt_tokens: data?.usage?.prompt_tokens ?? null,
      completion_tokens: data?.usage?.completion_tokens ?? null,
      cost: data?.usage?.cost ?? null,
    });
    if (res.ok && !data.error) {
      // 사진을 보냈는데 기록을 못 뽑았으면(사진 못 읽는 모델 등) 다음 모델로 한 번 더
      if (hasImages && i < list.length - 1) {
        let intent = '';
        try { intent = JSON.parse(String(data.choices?.[0]?.message?.content || '').match(/\{[\s\S]*\}/)?.[0] || '{}').intent; } catch {}
        if (intent && intent !== 'log') { lastStatus = 200; lastMsg = 'no-log'; last = data; continue; }
      }
      return json({ ...data, remaining: DAILY_LIMIT - used });
    }
    lastStatus = res.status; lastMsg = data?.error?.message ?? `HTTP ${res.status}`;
    if (res.status === 401 || res.status === 403) break; // 키 문제는 다른 모델로 넘어가도 같음
  }

  if (last) return json({ ...last, remaining: DAILY_LIMIT - used }); // 모두 '기록 아님'이면 마지막 답을 그대로
  // 5) 전부 실패 → 차감한 1회 돌려주기
  await admin.rpc('refund_ai_quota', { p_user: user.id });
  return fail(lastStatus === 429 ? 503 : 502, 'AI 서버가 응답하지 않아요. 잠시 후 다시 보내 주세요. (' + lastMsg + ')');
});
