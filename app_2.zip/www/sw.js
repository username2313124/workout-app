// 오프라인에서도 앱 화면이 열리도록 앱 파일을 기기에 보관한다.
// 앱을 고친 뒤에는 VERSION 을 바꾸면 새 파일로 교체된다.
const VERSION = 'v1';
const CACHE = 'workoutlog-' + VERSION;
const SHELL = ['./', 'index.html', 'css/app.css', 'js/app.js', 'js/ai.js', 'js/db.js', 'js/dashboard.js',
  'js/metrics.js', 'js/charts.js', 'manifest.webmanifest', 'icons/icon-180.png', 'icons/icon-192.png', 'icons/icon-512.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});
// 앱 파일: 네트워크 먼저(최신 버전), 안 되면 보관본. AI 서버 요청은 건드리지 않음.
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin) return;
  e.respondWith(
    fetch(e.request).then(res => {
      const copy = res.clone();
      caches.open(CACHE).then(c => c.put(e.request, copy));
      return res;
    }).catch(() => caches.match(e.request).then(r => r || caches.match('index.html')))
  );
});
