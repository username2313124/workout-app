// 외부 라이브러리 없이 SVG로 그리는 간단한 차트

const W = 340, H = 170, P = { l: 38, r: 10, t: 12, b: 26 };

function niceMax(v) {
  if (v <= 0) return 1;
  const p = Math.pow(10, Math.floor(Math.log10(v)));
  for (const m of [1, 2, 2.5, 5, 10]) if (v <= m * p) return m * p;
  return 10 * p;
}

const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const shortDate = d => d.slice(5).replace('-', '/');

function frame(maxV, fmt, minV = 0) {
  const ih = H - P.t - P.b;
  let s = '';
  for (let i = 0; i <= 3; i++) {
    const v = minV + ((maxV - minV) * i) / 3;
    const y = P.t + ih - (ih * i) / 3;
    s += `<line x1="${P.l}" x2="${W - P.r}" y1="${y}" y2="${y}" class="grid"/>`;
    s += `<text x="${P.l - 5}" y="${y + 3}" class="ax" text-anchor="end">${esc(fmt(v))}</text>`;
  }
  return s;
}

function xLabels(labels, xAt) {
  const n = labels.length, step = Math.max(1, Math.ceil(n / 5));
  let s = '';
  labels.forEach((l, i) => {
    if (i % step === 0 || i === n - 1) { const a = n > 1 && i === n - 1 ? 'end' : n > 1 && i === 0 ? 'start' : 'middle';
      s += `<text x="${xAt(i) + (a === 'end' ? 4 : a === 'start' ? -4 : 0)}" y="${H - 8}" class="ax" text-anchor="${a}">${esc(l)}</text>`; }
  });
  return s;
}

// points: [{x: 'YYYY-MM-DD', y: number}]
export function lineChart(points, fmt = v => v, opts = {}) {
  if (!points.length) return '<div class="empty">데이터 없음</div>';
  const ys = points.map(p => p.y);
  let lo = Math.min(...ys), hi = Math.max(...ys);
  if (opts.fromZero !== false && lo >= 0 && lo / (hi || 1) < 0.5) lo = 0;
  if (hi === lo) { if (hi > 0) { lo = 0; hi = hi * 1.5; } else { hi = hi + 1; lo = Math.max(0, lo - 1); } }
  const pad = (hi - lo) * 0.1; hi += pad; if (lo > 0) lo = Math.max(0, lo - pad);
  const iw = W - P.l - P.r, ih = H - P.t - P.b;
  const xAt = i => P.l + (points.length === 1 ? iw / 2 : (iw * i) / (points.length - 1));
  const yAt = v => P.t + ih - (ih * (v - lo)) / (hi - lo);
  const path = points.map((p, i) => `${i ? 'L' : 'M'}${xAt(i).toFixed(1)},${yAt(p.y).toFixed(1)}`).join('');
  const dots = points.map((p, i) =>
    `<circle cx="${xAt(i)}" cy="${yAt(p.y)}" r="3" class="dot"><title>${esc(p.x)}: ${esc(fmt(p.y))}</title></circle>`).join('');
  return `<svg viewBox="0 0 ${W} ${H}" class="chart">${frame(hi, fmt, lo)}
    <path d="${path}" class="line"/>${dots}${xLabels(points.map(p => shortDate(p.x)), xAt)}</svg>`;
}

// bars: [{label, value}]
export function barChart(bars, fmt = v => v, { dateLabels = false } = {}) {
  if (!bars.length) return '<div class="empty">데이터 없음</div>';
  const hi = niceMax(Math.max(...bars.map(b => b.value)));
  const iw = W - P.l - P.r, ih = H - P.t - P.b;
  const bw = iw / bars.length;
  const xAt = i => P.l + bw * i + bw / 2;
  const rects = bars.map((b, i) => {
    const h = (ih * b.value) / hi;
    const w = Math.max(2, Math.min(28, bw * 0.7));
    return `<rect x="${xAt(i) - w / 2}" y="${P.t + ih - h}" width="${w}" height="${h}" rx="2" class="bar">
      <title>${esc(b.label)}: ${esc(fmt(b.value))}</title></rect>`;
  }).join('');
  const labels = bars.map(b => (dateLabels ? shortDate(b.label) : b.label));
  return `<svg viewBox="0 0 ${W} ${H}" class="chart">${frame(hi, fmt)}${rects}${xLabels(labels, xAt)}</svg>`;
}

// 가로 막대 (종류별 비교)
export function hBarChart(bars, fmt = v => v) {
  if (!bars.length) return '<div class="empty">데이터 없음</div>';
  const hi = Math.max(...bars.map(b => b.value)) || 1;
  return `<div class="hbars">${bars.map(b => `
    <div class="hbar-row"><span class="hbar-label">${esc(b.label)}</span>
      <span class="hbar-track"><span class="hbar-fill" style="width:${(100 * b.value / hi).toFixed(1)}%"></span></span>
      <span class="hbar-val">${esc(fmt(b.value))}</span></div>`).join('')}</div>`;
}
