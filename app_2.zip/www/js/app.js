import { db, isNative } from './db.js';
import { validateKey, parseWorkout, PROVIDERS, listVisionModels, pickDefaultModel, usableModelId } from './ai.js';
import { renderDashboard } from './dashboard.js';

const DEFAULT_MODEL = 'gpt-4.1-mini';
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const today = () => new Date().toLocaleDateString('sv-SE'); // YYYY-MM-DD (기기 시간대)

const state = { provider: 'openai', setupProvider: 'openai', models: null, apiKey: null, model: DEFAULT_MODEL, history: [], busy: false, images: [], imagesOnlyText: false, maxImages: 4 };

function drawAttach() {
  const box = $('#attach');
  box.hidden = !state.images.length;
  box.innerHTML = state.images.map((f, i) => `<div class="thumb"><img src="${URL.createObjectURL(f)}" alt="첨부 사진 ${i + 1}"><button type="button" data-rm="${i}" aria-label="사진 빼기">✕</button></div>`).join('');
  $('#input').placeholder = state.images.length ? '사진에 대해 덧붙일 말 (없으면 그냥 보내기)' : '오늘 무슨 운동 했어요? 기록 사진도 돼요';
}
function clearAttach() { state.images = []; $('#photo').value = ''; drawAttach(); }

/* ---------------- 모달 ---------------- */
function openModal(html) {
  const root = $('#modal');
  root.innerHTML = `<div class="sheet">${html}</div>`;
  root.classList.add('show');
  return root.querySelector('.sheet');
}
function closeModal() { $('#modal').classList.remove('show'); $('#modal').innerHTML = ''; }

// 새 운동종류 질문: 새로 추가 / 기존 종류에 넣기 / 이 기록 빼기
function askNewType(rec, types) {
  return new Promise(resolve => {
    const cands = (rec.candidates || []).filter(c => types.includes(c));
    const rest = types.filter(t => !cands.includes(t));
    const s = openModal(`
      <h2>새 운동종류가 필요해요</h2>
      <p class="lead"><b>${esc(rec.exercise_name || rec.exercise_type)}</b> 기록은 기존 종류에 없는 <b>'${esc(rec.exercise_type)}'</b>(으)로 분류됐어요.</p>
      <button class="btn primary block" data-act="new">'${esc(rec.exercise_type)}' 종목 새로 추가</button>
      ${types.length ? `<div class="divider">또는 기존 종목에 넣기</div>
      <div class="chips wrap">${[...cands, ...rest].map(t => `<button class="chip ${cands.includes(t) ? 'on' : ''}" data-act="use" data-type="${esc(t)}">${esc(t)}</button>`).join('')}</div>` : ''}
      <button class="btn ghost block" data-act="skip">이 기록은 빼기</button>`);
    s.addEventListener('click', e => {
      const b = e.target.closest('[data-act]'); if (!b) return;
      closeModal();
      if (b.dataset.act === 'new') resolve(rec.exercise_type);
      else if (b.dataset.act === 'use') resolve(b.dataset.type);
      else resolve(null);
    });
  });
}

function recForm(r, i, types) {
  return `
  <div class="rec" data-i="${i}">
    <div class="rec-h"><b>${esc(r.exercise_type)}${r.exercise_name ? ' · ' + esc(r.exercise_name) : ''}</b>
      ${i != null ? `<button class="x" data-del="${i}" aria-label="이 항목 빼기">✕</button>` : ''}</div>
    <div class="grid2">
      <label>날짜<input type="date" name="date" value="${esc(r.date)}"></label>
      <label>운동시간(분)<input type="number" inputmode="decimal" name="duration_min" value="${r.duration_min ?? ''}"></label>
      <label>운동종류<input name="exercise_type" list="typelist" value="${esc(r.exercise_type)}"></label>
      <label>세부운동<input name="exercise_name" value="${esc(r.exercise_name)}"></label>
    </div>
    <label>대표 결과<input name="result_summary" value="${esc(r.result_summary)}"></label>
    <label>메모<input name="memo" value="${esc(r.memo)}"></label>
    <details><summary>세부정보 (detail_json)</summary>
      <textarea name="detail_json" rows="6" spellcheck="false">${esc(JSON.stringify(r.detail_json ?? r.detail ?? {}, null, 2))}</textarea></details>
  </div>`;
}

function readForm(el) {
  const g = n => el.querySelector(`[name="${n}"]`).value.trim();
  let detail;
  try { detail = JSON.parse(g('detail_json') || '{}'); } catch { throw new Error('세부정보(JSON) 형식이 올바르지 않아요.'); }
  if (!g('date') || !g('exercise_type')) throw new Error('날짜와 운동종류는 꼭 필요해요.');
  const dur = g('duration_min');
  return {
    date: g('date'), exercise_type: g('exercise_type'), exercise_name: g('exercise_name') || null,
    duration_min: dur === '' ? null : Number(dur), result_summary: g('result_summary') || null,
    detail_json: detail, memo: g('memo') || null,
  };
}

// "오늘 운동은 다음과 같이 기록할까요?"
function confirmRecords(records, types) {
  return new Promise(resolve => {
    let recs = records.slice();
    const isToday = recs.every(r => r.date === today());
    const draw = () => {
      const s = openModal(`
        <h2>${isToday ? '오늘 운동은' : '운동을'} 다음과 같이 기록할까요?</h2>
        <datalist id="typelist">${types.map(t => `<option value="${esc(t)}">`).join('')}</datalist>
        <div class="recs">${recs.map((r, i) => recForm(r, i, types)).join('')}</div>
        <p class="err" hidden></p>
        <div class="actions"><button class="btn ghost" data-act="cancel">취소</button>
          <button class="btn primary" data-act="ok">확인</button></div>`);
      s.addEventListener('click', e => {
        const del = e.target.closest('[data-del]');
        if (del) {
          // 입력 중인 값 유지
          recs = [...s.querySelectorAll('.rec')].map((el, i) => { try { return readForm(el); } catch { return recs[i]; } });
          recs.splice(Number(del.dataset.del), 1);
          if (!recs.length) { closeModal(); return resolve(null); }
          return draw();
        }
        const b = e.target.closest('[data-act]'); if (!b) return;
        if (b.dataset.act === 'cancel') { closeModal(); return resolve(null); }
        try {
          const out = [...s.querySelectorAll('.rec')].map(readForm);
          closeModal(); resolve(out);
        } catch (err) { const p = s.querySelector('.err'); p.textContent = err.message; p.hidden = false; }
      });
    };
    draw();
  });
}

async function editRecord(id) {
  const rec = (await db.all()).find(r => r.id === id);
  if (!rec) return;
  const types = await db.types();
  const s = openModal(`
    <h2>기록 수정</h2>
    <datalist id="typelist">${types.map(t => `<option value="${esc(t)}">`).join('')}</datalist>
    ${recForm(rec, null, types)}
    <p class="err" hidden></p>
    <div class="actions"><button class="btn danger" data-act="del">삭제</button>
      <span class="sp"></span>
      <button class="btn ghost" data-act="cancel">닫기</button><button class="btn primary" data-act="ok">저장</button></div>`);
  s.addEventListener('click', async e => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    if (b.dataset.act === 'cancel') return closeModal();
    if (b.dataset.act === 'del') {
      if (b.dataset.sure) { await db.remove(id); closeModal(); return refreshDash(); }
      b.dataset.sure = '1'; b.textContent = '정말 삭제'; return;
    }
    try { await db.update(id, readForm(s.querySelector('.rec'))); closeModal(); refreshDash(); }
    catch (err) { const p = s.querySelector('.err'); p.textContent = err.message; p.hidden = false; }
  });
}

/* ---------------- 채팅 ---------------- */
function bubble(role, html) {
  const d = document.createElement('div');
  d.className = `msg ${role}`;
  d.innerHTML = html;
  $('#messages').appendChild(d);
  $('#messages').scrollTop = $('#messages').scrollHeight;
  return d;
}

async function send(text) {
  const images = state.images.slice();
  if (state.busy || (!text.trim() && !images.length)) return;
  if (!text.trim()) text = '이 사진의 운동 기록을 분석해서 기록해줘';
  state.busy = true; $('#send').disabled = true;
  const pics = images.length ? `<div class="pics">${images.map(f => `<img src="${URL.createObjectURL(f)}" alt="첨부한 기록 사진">`).join('')}</div>` : '';
  bubble('user', pics + `<span>${state.imagesOnlyText ? '' : esc(text)}</span>`);
  clearAttach();
  const wait = bubble('bot', '<span class="typing"><i></i><i></i><i></i></span>' + (images.length ? ' <span class="muted small">사진 분석 중…</span>' : ''));
  try {
    const all = await db.all();
    const types = [...new Set(all.map(r => r.exercise_type))];
    const names = [...new Set(all.map(r => r.exercise_name).filter(Boolean))];
    const out = await parseWorkout({ provider: state.provider, apiKey: state.apiKey, model: state.model, history: state.history, text, today: today(), types, names, images });
    state.history.push({ role: 'user', content: images.length ? `${text} (기록 사진 ${images.length}장 첨부)` : text });
    wait.remove();

    if (out.intent !== 'log' || !out.records.length) {
      const msg = out.reply || '운동 기록에 대해 말씀해 주세요. 예: "오늘 5km 34분 뛰었어"';
      bubble('bot', esc(msg));
      state.history.push({ role: 'assistant', content: msg });
      return;
    }

    // 7) 새 운동종류면 사용자에게 묻기
    const recs = [], decided = {};
    for (const r of out.records) {
      if (!types.includes(r.exercise_type)) {
        const orig = r.exercise_type;
        const chosen = orig in decided ? decided[orig] : (decided[orig] = await askNewType(r, types));
        if (!chosen) continue;
        r.exercise_type = chosen;
      }
      recs.push(r);
    }
    for (const v of Object.values(decided)) if (v && !types.includes(v)) types.push(v);
    if (!recs.length) { bubble('bot', '기록하지 않았어요.'); return; }

    // 확인 창 → 확인 시 DB 반영
    const final = await confirmRecords(recs, types);
    if (!final) {
      bubble('bot', '기록을 취소했어요. 내용을 고쳐서 다시 말씀해 주셔도 돼요.');
      state.history.push({ role: 'assistant', content: '(사용자가 기록을 취소함)' });
      return;
    }
    for (const r of final) await db.insert(r);
    const summary = final.map(r => `<li><b>${esc(r.exercise_type)}${r.exercise_name ? ' · ' + esc(r.exercise_name) : ''}</b> ${esc(r.result_summary || '')}</li>`).join('');
    bubble('bot', `${final.length}건 기록했어요.<ul>${summary}</ul>`);
    state.history.push({ role: 'assistant', content: `기록 완료: ${JSON.stringify(final.map(r => ({ date: r.date, type: r.exercise_type, name: r.exercise_name })))}` });
  } catch (err) {
    wait.remove();
    bubble('bot err', `오류: ${esc(err.message)}`);
  } finally {
    state.busy = false; $('#send').disabled = false;
  }
}

/* ---------------- 화면 전환 ---------------- */
async function refreshDash() { renderDashboard($('#view-dash'), await db.all(), today(), editRecord); }

function show(view) {
  document.querySelectorAll('.view').forEach(v => v.hidden = v.id !== `view-${view}`);
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('on', t.dataset.view === view));
  $('#title').textContent = { chat: '운동 기록', dash: '대시보드', settings: '설정' }[view];
  if (view === 'dash') refreshDash();
  if (view === 'settings') drawSettings();
}

async function drawSettings() {
  const n = (await db.all()).length;
  const k = state.apiKey || '';
  $('#view-settings').innerHTML = `
    <section class="card"><h3>AI 서비스</h3>
      <p class="muted">${esc(PROVIDERS[state.provider].label)} · 키 ${k ? esc(k.slice(0, 7)) + '…' + esc(k.slice(-4)) : '없음'}</p>
      <button class="btn block" id="chg-key">서비스·API 키 변경</button></section>
    <section class="card"><h3>모델</h3>
      ${state.provider === 'openrouter' ? `
        <select id="model-select"><option value="">목록 불러오는 중…</option></select>
        <p class="muted small">사진을 읽을 수 있는 모델만 보여요. 가격은 100만 토큰당 입력/출력 달러이고, 기록 1건은 보통 수천 토큰이에요. 무료 모델은 사용량 제한이 있어요.</p>
        <button class="btn block" id="reload-models">모델 목록 새로고침</button>` : ''}
      <input id="model" value="${esc(state.model)}" placeholder="모델 이름">
      <p class="muted small">${state.provider === 'openrouter' ? '목록에 없으면 모델 ID를 직접 입력해도 돼요 (예: openai/gpt-4.1-mini).' : `기본값 ${DEFAULT_MODEL}. 사진을 읽을 수 있는 모델이어야 해요.`}</p></section>
    <section class="card"><h3>데이터</h3>
      <p class="muted">저장된 기록 ${n}건 · ${isNative() ? '폰 내부 SQLite' : '이 기기 안 (앱 저장소)'}</p>
      <button class="btn block" id="export">CSV로 내보내기 (백업)</button>
      <label class="btn block" for="import-file" style="text-align:center">백업 CSV 불러오기</label>
      <input id="import-file" class="sr" type="file" accept=".csv,text/csv" tabindex="-1">
      <p class="muted small" id="import-msg" hidden></p>
      <button class="btn block" id="sample">샘플 데이터 넣기</button>
      <button class="btn danger block" id="wipe">모든 기록 삭제</button></section>`;
  $('#model').addEventListener('change', async e => { await setModel(e.target.value.trim() || (state.provider === 'openai' ? DEFAULT_MODEL : '')); });
  if (state.provider === 'openrouter') {
    fillModelSelect();
    $('#model-select').addEventListener('change', e => { if (e.target.value) setModel(e.target.value); });
    $('#reload-models').addEventListener('click', () => { state.models = null; fillModelSelect(); });
  }
  $('#chg-key').addEventListener('click', () => showSetup(true));
  $('#export').addEventListener('click', exportCsv);
  $('#import-file').addEventListener('change', async e => {
    const f = e.target.files[0]; e.target.value = '';
    if (!f) return;
    const msg = $('#import-msg'); msg.hidden = false;
    try { const n = await importCsv(await f.text()); msg.textContent = `${n}건을 불러왔어요. (이미 있는 기록은 건너뜀)`; setTimeout(drawSettings, 1500); }
    catch (err) { msg.textContent = err.message; }
  });
  $('#sample').addEventListener('click', async () => { await insertSample(); drawSettings(); });
  $('#wipe').addEventListener('click', async e => {
    if (!e.target.dataset.sure) { e.target.dataset.sure = '1'; e.target.textContent = '한 번 더 누르면 전부 삭제'; return; }
    await db.clear(); drawSettings();
  });
}

async function setModel(m) {
  state.model = m; await db.setSetting('model', m);
  const inp = $('#model'); if (inp) inp.value = m;
  const sel = $('#model-select'); if (sel && [...sel.options].some(o => o.value === m)) sel.value = m;
}

const price = v => v === 0 ? '0' : v < 0.1 ? v.toFixed(3) : v < 10 ? v.toFixed(2) : v.toFixed(0);
async function fillModelSelect() {
  const sel = $('#model-select'); if (!sel) return;
  try {
    if (!state.models) state.models = await listVisionModels();
    const opt = m => `<option value="${esc(m.id)}">${esc(m.name)} — ${m.free ? '무료' : `$${price(m.inP)} / $${price(m.outP)}`}</option>`;
    const free = state.models.filter(m => m.free), paid = state.models.filter(m => !m.free);
    sel.innerHTML = `<option value="">모델 고르기</option>`
      + (free.length ? `<optgroup label="무료 (테스트용)">${free.map(opt).join('')}</optgroup>` : '')
      + `<optgroup label="유료">${paid.map(opt).join('')}</optgroup>`;
    if (state.model) sel.value = state.model;
  } catch (e) { sel.innerHTML = `<option value="">${esc(e.message)}</option>`; }
}

async function exportCsv() {
  const rows = await db.all();
  const cols = ['id', 'date', 'exercise_type', 'exercise_name', 'duration_min', 'result_summary', 'detail_json', 'memo', 'created_at', 'updated_at'];
  const q = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const csv = '﻿' + [cols.join(','), ...rows.map(r => cols.map(c => q(r[c])).join(','))].join('\n');
  try {
    if (navigator.share && isNative()) {
      const file = new File([csv], 'workout_logs.csv', { type: 'text/csv' });
      if (navigator.canShare?.({ files: [file] })) return navigator.share({ files: [file] });
    }
  } catch {}
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
  a.download = 'workout_logs.csv'; a.click();
}

function parseCsv(text) {
  const rows = []; let row = [], cell = '', q = false;
  text = text.replace(/^\uFEFF/, '');
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) { if (ch === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += ch; }
    else if (ch === '"') q = true;
    else if (ch === ',') { row.push(cell); cell = ''; }
    else if (ch === '\n' || ch === '\r') { if (ch === '\r' && text[i + 1] === '\n') i++; row.push(cell); rows.push(row); row = []; cell = ''; }
    else cell += ch;
  }
  if (cell || row.length) { row.push(cell); rows.push(row); }
  return rows.filter(r => r.some(c => c !== ''));
}

async function importCsv(text) {
  const [head, ...body] = parseCsv(text);
  if (!head || !head.includes('date') || !head.includes('exercise_type')) throw new Error('이 앱에서 내보낸 CSV 파일이 아니에요.');
  const ix = k => head.indexOf(k);
  const have = new Set((await db.all()).map(r => [r.date, r.exercise_type, r.exercise_name || '', r.result_summary || ''].join('|')));
  let n = 0;
  for (const c of body) {
    const g = k => (ix(k) >= 0 ? c[ix(k)] : '') || null;
    const rec = { date: g('date'), exercise_type: g('exercise_type'), exercise_name: g('exercise_name'),
      duration_min: g('duration_min') == null ? null : Number(g('duration_min')), result_summary: g('result_summary'),
      detail_json: (() => { try { return JSON.parse(g('detail_json') || '{}'); } catch { return {}; } })(), memo: g('memo') };
    if (!rec.date || !rec.exercise_type) continue;
    const key = [rec.date, rec.exercise_type, rec.exercise_name || '', rec.result_summary || ''].join('|');
    if (have.has(key)) continue;
    await db.insert(rec); have.add(key); n++;
  }
  return n;
}

async function insertSample() {
  const d = n => { const x = new Date(); x.setDate(x.getDate() - n); return x.toLocaleDateString('sv-SE'); };
  const S = [
    [20, '러닝', '야외 러닝', 30, '4km 무휴식', { distance_km: 4.0, pace_sec_per_km: 450, avg_heart_rate: 165, cadence: 150, continuous: true }, null],
    [17, '헬스', '풀업', 15, '보조 6/5/4회', { sets: [{ weight_kg: 0, reps: 6 }, { weight_kg: 0, reps: 5 }, { weight_kg: 0, reps: 4 }], assistance: 'band' }, null],
    [14, '러닝', '야외 러닝', 32, '4.5km 무휴식', { distance_km: 4.5, pace_sec_per_km: 427, avg_heart_rate: 170, max_heart_rate: 182, cadence: 152, continuous: true }, null],
    [12, '클라이밍', '볼더링', 120, '파랑3 빨강1', { gym: '더클라이밍 성수', problems: { blue: 3, red: 1 } }, '전완근 펌핑'],
    [10, '헬스', '스쿼트', 20, '20kg 6/5/4회', { sets: [{ weight_kg: 20, reps: 6 }, { weight_kg: 20, reps: 5 }, { weight_kg: 20, reps: 4 }], assistance: null }, null],
    [7, '러닝', '야외 러닝', 34, '5km 무휴식', { distance_km: 5.0, pace_sec_per_km: 408, avg_heart_rate: 168, max_heart_rate: 181, cadence: 155, continuous: true }, '허벅지가 먼저 힘들었음'],
    [5, '클라이밍', '볼더링', 120, '파랑4 빨강2', { gym: '더클라이밍 성수', problems: { blue: 4, red: 2 } }, null],
    [3, '헬스', '스쿼트', 22, '25kg 6/6/5회', { sets: [{ weight_kg: 25, reps: 6 }, { weight_kg: 25, reps: 6 }, { weight_kg: 25, reps: 5 }], assistance: null }, null],
    [1, '러닝', '야외 러닝', 40, '6km 무휴식', { distance_km: 6.0, pace_sec_per_km: 400, avg_heart_rate: 166, max_heart_rate: 179, cadence: 157, continuous: true }, '컨디션 좋음'],
  ];
  for (const [n, t, nm, dur, sum, det, memo] of S)
    await db.insert({ date: d(n), exercise_type: t, exercise_name: nm, duration_min: dur, result_summary: sum, detail_json: det, memo });
}

/* ---------------- API 키 입력 ---------------- */
function drawSetupProvider() {
  const pv = PROVIDERS[state.setupProvider];
  document.querySelectorAll('[data-prov]').forEach(b => b.classList.toggle('on', b.dataset.prov === state.setupProvider));
  $('#key').placeholder = pv.keyPrefix + '...';
  $('#key-steps').innerHTML = state.setupProvider === 'openrouter'
    ? `<li>openrouter.ai 접속 → 로그인 (구글 계정 가능)</li><li>Keys → Create Key</li><li>sk-or- 로 시작하는 키를 복사해 아래에 붙여넣기</li><li>무료 모델로 시험해 볼 수 있고, 유료 모델은 Credits 충전이 필요해요</li>`
    : `<li>platform.openai.com 접속 → 로그인</li><li>API keys → Create new secret key</li><li>sk- 로 시작하는 키를 복사해 아래에 붙여넣기</li><li>Billing에서 크레딧 충전이 필요해요 (ChatGPT 구독과 별개)</li>`;
}

function showSetup(canCancel = false) {
  state.setupProvider = state.provider;
  drawSetupProvider();
  $('#setup').hidden = false;
  $('#setup-cancel').hidden = !canCancel;
  $('#key').value = '';
  $('#setup-err').hidden = true;
}

async function saveKey() {
  const k = $('#key').value.trim();
  const err = $('#setup-err');
  const prov = state.setupProvider, pv = PROVIDERS[prov];
  if (!k.startsWith(pv.keyPrefix)) { err.textContent = `${pv.label} API 키는 ${pv.keyPrefix} 로 시작해요.`; err.hidden = false; return; }
  $('#save-key').disabled = true; $('#save-key').textContent = '확인 중…';
  try {
    await validateKey(prov, k);
    const changed = prov !== state.provider;
    state.provider = prov; state.apiKey = k;
    await db.setSetting('provider', prov); await db.setSetting('api_key', k);
    if (changed || !state.model) {
      let m = pv.defaultModel;
      if (prov === 'openrouter') {
        try { state.models = await listVisionModels(); m = pickDefaultModel(state.models); } catch { m = ''; }
      }
      await setModel(m);
    }
    $('#setup').hidden = true;
    if (!$('#view-settings').hidden) drawSettings();
    bubble('bot', `${esc(pv.label)}로 연결했어요.${state.model ? ` 모델: ${esc(state.model)}` : ' 설정 탭에서 모델을 골라 주세요.'}`);
  } catch (e) { err.textContent = e.message; err.hidden = false; }
  finally { $('#save-key').disabled = false; $('#save-key').textContent = '시작하기'; }
}

/* ---------------- 시작 ---------------- */
async function main() {
  await db.init();
  state.apiKey = await db.getSetting('api_key');
  state.provider = (await db.getSetting('provider')) || 'openai';
  state.model = (await db.getSetting('model')) ?? (state.provider === 'openai' ? DEFAULT_MODEL : '');
  // 예전 버전이 고른 쓸 수 없는 모델(예: ...:batch)은 기본 모델로 바로잡기
  if (state.provider === 'openrouter' && state.model && !usableModelId(state.model)) {
    state.model = state.model.split(':')[0];
    await db.setSetting('model', state.model);
  }

  document.querySelectorAll('.tab').forEach(t => t.addEventListener('click', () => show(t.dataset.view)));
  $('#composer').addEventListener('submit', e => { e.preventDefault(); const v = $('#input').value; $('#input').value = ''; state.imagesOnlyText = !v.trim() && state.images.length > 0; send(v); });
  $('#photo').addEventListener('change', e => {
    const files = [...e.target.files].filter(f => /^image\//.test(f.type) || !f.type);
    state.images = [...state.images, ...files].slice(0, state.maxImages);
    e.target.value = '';
    drawAttach();
  });
  $('#attach').addEventListener('click', e => { const b = e.target.closest('[data-rm]'); if (!b) return; state.images.splice(Number(b.dataset.rm), 1); drawAttach(); });
  document.querySelector('.photo-hint').addEventListener('click', () => $('#photo').click());
  $('#save-key').addEventListener('click', saveKey);
  $('#prov').addEventListener('click', e => { const b = e.target.closest('[data-prov]'); if (!b) return; state.setupProvider = b.dataset.prov; drawSetupProvider(); });
  $('#setup-cancel').addEventListener('click', () => { $('#setup').hidden = true; });
  $('#modal').addEventListener('click', e => { if (e.target.id === 'modal') { /* 바깥 탭으로 닫지 않음 */ } });
  document.querySelectorAll('.hint:not(.photo-hint)').forEach(h => h.addEventListener('click', () => { $('#input').value = h.textContent; $('#input').focus(); }));

  bubble('bot', '오늘 한 운동을 편하게 말해 주세요. 러닝앱이나 클라이밍 기록 공유 사진을 올려도 돼요.<br>예: "오늘 야외에서 5km 34분 뛰었어. 페이스 6분48초, 허벅지가 먼저 힘들었음"');
  show('chat');
  if (!state.apiKey) showSetup(false);
  setupPwa();
}

// 웹앱(아이폰·브라우저)으로 열었을 때: 오프라인 보관 + 홈 화면 추가 안내
function setupPwa() {
  if (isNative()) return;
  if ('serviceWorker' in navigator && location.protocol === 'https:') navigator.serviceWorker.register('sw.js').catch(() => {});
  const standalone = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
  const ua = navigator.userAgent;
  const ios = /iPhone|iPad|iPod/i.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  let dismissed = false; try { dismissed = localStorage.getItem('wl_install_x') === '1'; } catch {}
  if (standalone || dismissed) return;
  if (ios) {
    if (!/Safari/i.test(ua) || /CriOS|FxiOS|EdgiOS|KAKAOTALK|NAVER|Instagram|FBAN/i.test(ua))
      $('#install-how').innerHTML = '<b>Safari</b>로 이 주소를 열어야 홈 화면에 추가할 수 있어요';
    $('#install').hidden = false;
  } else if (/Android/i.test(ua)) {
    $('#install-how').innerHTML = 'Chrome 메뉴 ⋮ → <b>홈 화면에 추가</b> (또는 앱 설치)';
    $('#install').hidden = false;
  }
  $('#install-x').addEventListener('click', () => { $('#install').hidden = true; try { localStorage.setItem('wl_install_x', '1'); } catch {} });
}

window.__app = { db, state, send, insertSample, show }; // 디버그/테스트용
main();
