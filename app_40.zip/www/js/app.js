import { db, isNative, toDetail } from './db.js';
import { validateKey, parseWorkout, PROVIDERS, listVisionModels, pickDefaultModel, usableModelId } from './ai.js';
import { renderDashboard } from './dashboard.js';
import { QuotaError, remainingToday } from './server.js';
import { account, signUp, logIn, logOut, getConsent, consentOk, agree, withdraw, syncNow, syncEnabled, watchChanges, isBound, bind } from './account.js';

const DEFAULT_MODEL = 'gpt-4.1-mini';
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const today = () => new Date().toLocaleDateString('sv-SE'); // YYYY-MM-DD (기기 시간대)

const state = { provider: 'server', setupProvider: 'openrouter', remaining: null, models: null, apiKey: null, model: DEFAULT_MODEL, history: [], busy: false, images: [], imagesOnlyText: false, maxImages: 4 };

function drawAttach() {
  const box = $('#attach');
  box.hidden = !state.images.length;
  box.innerHTML = state.images.map((f, i) => `<div class="thumb"><img src="${URL.createObjectURL(f)}" alt="첨부 사진 ${i + 1}"><button type="button" data-rm="${i}" aria-label="사진 빼기">✕</button></div>`).join('');
  $('#input').placeholder = state.images.length ? '사진에 대해 덧붙일 말 (없으면 그냥 보내기)' : '오늘 무슨 운동 했어요? 기록 사진도 돼요';
}
function clearAttach() { state.images = []; $('#photo').value = ''; drawAttach(); }

/* ---------------- 모달 ---------------- */
function openModal(html) {
  const root = $('#modal');
  root.innerHTML = `<div class="sheet">${html}</div>`;
  root.classList.add('show');
  return root.querySelector('.sheet');
}
function closeModal() { $('#modal').classList.remove('show'); $('#modal').innerHTML = ''; }

// 새 운동종류 질문: 새로 추가 / 기존 종류에 넣기 / 이 기록 빼기
function askNewType(rec, types) {
  return new Promise(resolve => {
    const cands = (rec.candidates || []).filter(c => types.includes(c));
    const rest = types.filter(t => !cands.includes(t));
    const s = openModal(`
      <h2>새 운동종류가 필요해요</h2>
      <p class="lead"><b>${esc(rec.exercise_name || rec.exercise_type)}</b> 기록은 기존 종류에 없는 <b>'${esc(rec.exercise_type)}'</b>(으)로 분류됐어요.</p>
      <button class="btn primary block" data-act="new">'${esc(rec.exercise_type)}' 종목 새로 추가</button>
      ${types.length ? `<div class="divider">또는 기존 종목에 넣기</div>
      <div class="chips wrap">${[...cands, ...rest].map(t => `<button class="chip ${cands.includes(t) ? 'on' : ''}" data-act="use" data-type="${esc(t)}">${esc(t)}</button>`).join('')}</div>` : ''}
      <button class="btn ghost block" data-act="skip">이 기록은 빼기</button>`);
    s.addEventListener('click', e => {
      const b = e.target.closest('[data-act]'); if (!b) return;
      closeModal();
      if (b.dataset.act === 'new') resolve(rec.exercise_type);
      else if (b.dataset.act === 'use') resolve(b.dataset.type);
      else resolve(null);
    });
  });
}

function recForm(r, i, types) {
  return `
  <div class="rec" data-i="${i}">
    <div class="rec-h"><b>${esc(r.exercise_type)}${r.exercise_name ? ' · ' + esc(r.exercise_name) : ''}</b>
      ${i != null ? `<button class="x" data-del="${i}" aria-label="이 항목 빼기">✕</button>` : ''}</div>
    <div class="grid2">
      <label>날짜<input type="date" name="date" value="${esc(r.date)}"></label>
      <label>운동시간(분)<input type="number" inputmode="decimal" name="duration_min" value="${r.duration_min ?? ''}"></label>
      <label>운동종류<input name="exercise_type" list="typelist" value="${esc(r.exercise_type)}"></label>
      <label>세부운동<input name="exercise_name" value="${esc(r.exercise_name)}"></label>
    </div>
    <label>대표 결과<input name="result_summary" value="${esc(r.result_summary)}"></label>
    <label>메모<input name="memo" value="${esc(r.memo)}"></label>
    <details><summary>세부정보 (detail_json)</summary>
      <textarea name="detail_json" rows="6" spellcheck="false">${esc(JSON.stringify(r.detail ?? toDetail(r.detail_json), null, 2))}</textarea></details>
  </div>`;
}

function readForm(el) {
  const g = n => el.querySelector(`[name="${n}"]`).value.trim();
  let detail;
  try { detail = JSON.parse(g('detail_json') || '{}'); } catch { throw new Error('세부정보(JSON) 형식이 올바르지 않아요.'); }
  if (!g('date') || !g('exercise_type')) throw new Error('날짜와 운동종류는 꼭 필요해요.');
  const dur = g('duration_min');
  return {
    date: g('date'), exercise_type: g('exercise_type'), exercise_name: g('exercise_name') || null,
    duration_min: dur === '' ? null : Number(dur), result_summary: g('result_summary') || null,
    detail_json: detail, memo: g('memo') || null,
  };
}

// "오늘 운동은 다음과 같이 기록할까요?"
function confirmRecords(records, types) {
  return new Promise(resolve => {
    let recs = records.slice();
    const isToday = recs.every(r => r.date === today());
    const draw = () => {
      const s = openModal(`
        <h2>${isToday ? '오늘 운동은' : '운동을'} 다음과 같이 기록할까요?</h2>
        <datalist id="typelist">${types.map(t => `<option value="${esc(t)}">`).join('')}</datalist>
        <div class="recs">${recs.map((r, i) => recForm(r, i, types)).join('')}</div>
        <p class="err" hidden></p>
        <div class="actions"><button class="btn ghost" data-act="cancel">취소</button>
          <button class="btn primary" data-act="ok">확인</button></div>`);
      s.addEventListener('click', e => {
        const del = e.target.closest('[data-del]');
        if (del) {
          // 입력 중인 값 유지
          recs = [...s.querySelectorAll('.rec')].map((el, i) => { try { return readForm(el); } catch { return recs[i]; } });
          recs.splice(Number(del.dataset.del), 1);
          if (!recs.length) { closeModal(); return resolve(null); }
          return draw();
        }
        const b = e.target.closest('[data-act]'); if (!b) return;
        if (b.dataset.act === 'cancel') { closeModal(); return resolve(null); }
        try {
          const out = [...s.querySelectorAll('.rec')].map(readForm);
          closeModal(); resolve(out);
        } catch (err) { const p = s.querySelector('.err'); p.textContent = err.message; p.hidden = false; }
      });
    };
    draw();
  });
}

async function editRecord(id) {
  const rec = (await db.all()).find(r => r.id === id);
  if (!rec) return;
  const types = await db.types();
  const s = openModal(`
    <h2>기록 수정</h2>
    <datalist id="typelist">${types.map(t => `<option value="${esc(t)}">`).join('')}</datalist>
    ${recForm(rec, null, types)}
    <p class="err" hidden></p>
    <div class="actions"><button class="btn danger" data-act="del">삭제</button>
      <span class="sp"></span>
      <button class="btn ghost" data-act="cancel">닫기</button><button class="btn primary" data-act="ok">저장</button></div>`);
  s.addEventListener('click', async e => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    if (b.dataset.act === 'cancel') return closeModal();
    if (b.dataset.act === 'del') {
      if (b.dataset.sure) { await db.remove(id); closeModal(); return refreshDash(); }
      b.dataset.sure = '1'; b.textContent = '정말 삭제'; return;
    }
    try { await db.update(id, readForm(s.querySelector('.rec'))); closeModal(); refreshDash(); }
    catch (err) { const p = s.querySelector('.err'); p.textContent = err.message; p.hidden = false; }
  });
}

/* ---------------- 채팅 ---------------- */
function bubble(role, html) {
  const d = document.createElement('div');
  d.className = `msg ${role}`;
  d.innerHTML = html;
  $('#messages').appendChild(d);
  $('#messages').scrollTop = $('#messages').scrollHeight;
  return d;
}

// AI가 칭찬·비교를 할 수 있게 최근 60일 기록을 짧게 요약 (최대 25건, 토큰 절약)
function recentForAi(all) {
  const since = new Date(Date.now() - 60 * 864e5).toLocaleDateString('sv-SE');
  return all.filter(r => r.date >= since).slice(0, 25).map(r => {
    // 구간·랩 목록은 길어서 빼고 요약 지표만 (인터벌은 run_avg_pace_sec_per_km 로 비교)
    let d = r.detail && typeof r.detail === 'object'
      ? JSON.stringify(Object.fromEntries(Object.entries(r.detail).filter(([k]) => !['intervals', 'laps', 'segments', '_chart'].includes(k))))
      : (r.detail_json || '');
    if (typeof d !== 'string') d = JSON.stringify(d);
    if (d === '{}') d = '';
    const seg = r.detail && typeof r.detail === 'object' && (Array.isArray(r.detail.segments) ? r.detail.segments : Array.isArray(r.detail.intervals) ? r.detail.intervals : null);
    if (seg && seg.length) d = `[구간 ${seg.length}개 있음] ` + d;
    if (d.length > 160) d = d.slice(0, 160) + '…';
    return `- ${r.date} ${r.exercise_type}${r.exercise_name ? '/' + r.exercise_name : ''}${r.duration_min ? ' ' + r.duration_min + '분' : ''} ${r.result_summary || ''} ${d}${r.memo ? ' (느낌: ' + r.memo + ')' : ''}`.replace(/\s+/g, ' ').trim();
  }).join('\n');
}

async function send(text) {
  const images = state.images.slice();
  if (state.busy || (!text.trim() && !images.length)) return;
  if (!text.trim()) text = '이 사진의 운동 기록을 분석해서 기록해줘';
  state.busy = true; $('#send').disabled = true;
  const pics = images.length ? `<div class="pics">${images.map(f => `<img src="${URL.createObjectURL(f)}" alt="첨부한 기록 사진">`).join('')}</div>` : '';
  bubble('user', pics + `<span>${state.imagesOnlyText ? '' : esc(text)}</span>`);
  clearAttach();
  const wait = bubble('bot', '<span class="typing"><i></i><i></i><i></i></span>' + (images.length ? ' <span class="muted small">사진 분석 중…</span>' : ''));
  try {
    const all = await db.all();
    const types = [...new Set(all.map(r => r.exercise_type))];
    const names = [...new Set(all.map(r => r.exercise_name).filter(Boolean))];
    const out = await parseWorkout({ provider: state.provider, apiKey: state.apiKey, model: state.model, history: state.history, text, today: today(), types, names, recent: recentForAi(all), images });
    if (typeof out.remaining === 'number') { state.remaining = out.remaining; drawQuota(); }
    state.history.push({ role: 'user', content: images.length ? `${text} (기록 사진 ${images.length}장 첨부)` : text });
    wait.remove();

    if (out.intent !== 'log' || !out.records.length) {
      const msg = out.reply || (images.length
        ? '사진에서 운동 기록을 찾지 못했어요. 러닝앱·클라이밍 기록 화면이 잘 보이게 다시 올리거나, 숫자를 말로 알려 주세요.'
        : '운동 기록에 대해 말씀해 주세요. 예: "오늘 5km 34분 뛰었어"');
      bubble('bot', esc(msg));
      state.history.push({ role: 'assistant', content: msg });
      return;
    }

    // 7) 새 운동종류면 사용자에게 묻기
    const recs = [], decided = {};
    for (const r of out.records) {
      if (!types.includes(r.exercise_type)) {
        const orig = r.exercise_type;
        const chosen = orig in decided ? decided[orig] : (decided[orig] = await askNewType(r, types));
        if (!chosen) continue;
        r.exercise_type = chosen;
      }
      recs.push(r);
    }
    for (const v of Object.values(decided)) if (v && !types.includes(v)) types.push(v);
    if (!recs.length) { bubble('bot', '기록하지 않았어요.'); return; }

    // 확인 창 → 확인 시 DB 반영
    const final = await confirmRecords(recs, types);
    if (!final) {
      bubble('bot', '기록을 취소했어요. 내용을 고쳐서 다시 말씀해 주셔도 돼요.');
      state.history.push({ role: 'assistant', content: '(사용자가 기록을 취소함)' });
      return;
    }
    for (const r of final) await db.insert(r);
    const summary = final.map(r => `<li><b>${esc(r.exercise_type)}${r.exercise_name ? ' · ' + esc(r.exercise_name) : ''}</b> ${esc(r.result_summary || '')}</li>`).join('');
    if (out.reply) bubble('bot', esc(out.reply).replace(/\n/g, '<br>'));
    bubble('bot', `<span class="muted small">${final.length}건 기록했어요</span><ul>${summary}</ul>`);
    state.history.push({ role: 'assistant', content: `${out.reply ? out.reply + '\n' : ''}기록 완료: ${JSON.stringify(final.map(r => ({ date: r.date, type: r.exercise_type, name: r.exercise_name })))}` });
  } catch (err) {
    wait.remove();
    if (err instanceof QuotaError) {
      state.remaining = 0; drawQuota();
      const b = bubble('bot err', `${esc(err.message).replace(/\n/g, '<br>')}<br><button class="btn primary" type="button">내 API 키 입력하기</button>`);
      b.querySelector('button').addEventListener('click', () => showSetup(true));
    } else bubble('bot err', `오류: ${esc(err.message).replace(/\n/g, '<br>')}`);
  } finally {
    state.busy = false; $('#send').disabled = false;
  }
}

/* ---------------- 화면 전환 ---------------- */
async function refreshDash() { renderDashboard($('#view-dash'), await db.all(), today(), editRecord); }

function show(view) {
  document.querySelectorAll('.view').forEach(v => v.hidden = v.id !== `view-${view}`);
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('on', t.dataset.view === view));
  $('#title').textContent = { chat: 'Caldron AI', dash: '대시보드', settings: '설정' }[view];
  if (view === 'dash') refreshDash();
  if (view === 'settings') drawSettings();
}

async function drawSettings() {
  const n = (await db.all()).length;
  const k = state.apiKey || '';
  $('#view-settings').innerHTML = `
    <section class="card"><h3>AI 연결 방식</h3>
      <div class="chips wrap" id="ai-mode">
        <button class="chip ${state.provider === 'server' ? 'on' : ''}" type="button" data-mode="server">기본 (무료)</button>
        <button class="chip ${state.provider !== 'server' ? 'on' : ''}" type="button" data-mode="own">내 API 키</button>
      </div>
      ${state.provider === 'server'
        ? `<p class="muted">앱이 제공하는 AI를 써요. 하루 사용 횟수가 정해져 있고, 한국 시간 0시에 다시 차요.${state.remaining != null ? ` <b>오늘 남은 횟수 ${state.remaining}회</b>` : ''}</p>
           <p class="muted small">더 많이 쓰려면 "내 API 키"를 골라 OpenAI 또는 OpenRouter 키를 넣으세요.</p>`
        : `<p class="muted">${esc(PROVIDERS[state.provider].label)} · 키 ${k ? esc(k.slice(0, 7)) + '…' + esc(k.slice(-4)) : '없음'}</p>
           <button class="btn block" id="chg-key">서비스·API 키 변경</button>
           <button class="btn danger block" id="del-key">저장된 키 삭제</button>`}</section>
    ${state.provider === 'server' ? '' : `<section class="card"><h3>모델</h3>
      ${state.provider === 'openrouter' ? `
        <select id="model-select"><option value="">목록 불러오는 중…</option></select>
        <p class="muted small">사진을 읽을 수 있는 모델만 보여요. 가격은 100만 토큰당 입력/출력 달러이고, 기록 1건은 보통 수천 토큰이에요. 무료 모델은 사용량 제한이 있어요.</p>
        <button class="btn block" id="reload-models">모델 목록 새로고침</button>` : ''}
      <input id="model" value="${esc(state.model)}" placeholder="모델 이름">
      <p class="muted small">${state.provider === 'openrouter' ? '목록에 없으면 모델 ID를 직접 입력해도 돼요 (예: openai/gpt-4.1-mini).' : `기본값 ${DEFAULT_MODEL}. 사진을 읽을 수 있는 모델이어야 해요.`}</p></section>`}
    <section class="card" id="acct-card"><h3>계정 · 서버 백업</h3><p class="muted small">불러오는 중…</p></section>
    <section class="card"><h3>데이터</h3>
      <p class="muted" id="data-count">저장된 기록 ${n}건 · ${isNative() ? '폰 내부 SQLite' : '이 기기 안 (앱 저장소)'}</p>
      <button class="btn block" id="export">CSV로 내보내기 (백업)</button>
      <label class="btn block" for="import-file" style="text-align:center">백업 CSV 불러오기</label>
      <input id="import-file" class="sr" type="file" accept=".csv,text/csv" tabindex="-1">
      <p class="muted small" id="import-msg" hidden></p>
      <button class="btn danger block" id="wipe">모든 기록 삭제</button></section>
    <section class="card"><h3>Caldron AI <span class="beta">Beta</span></h3>
      <p class="muted small">베타 버전이에요. 불편한 점이나 아이디어는 <a href="mailto:4084hyun@naver.com">4084hyun@naver.com</a>으로 보내 주세요.</p>
      <a class="btn block" style="text-align:center;text-decoration:none;color:inherit" href="privacy.html" target="_blank" rel="noopener">개인정보 처리방침</a></section>`;
  $('#ai-mode').addEventListener('click', async e => {
    const b = e.target.closest('[data-mode]'); if (!b) return;
    if (b.dataset.mode === 'server') { if (state.provider !== 'server') await useServer(); }
    else if (state.provider === 'server') {
      const prov = await db.getSetting('own_provider');
      if (state.apiKey && prov) { state.provider = prov; await db.setSetting('provider', prov); state.model = (await db.getSetting('model')) || ''; drawSettings(); drawQuota(); }
      else showSetup(true);
    }
  });
  if (state.provider !== 'server') $('#model').addEventListener('change', async e => { await setModel(e.target.value.trim() || (state.provider === 'openai' ? DEFAULT_MODEL : '')); });
  if (state.provider === 'openrouter') {
    fillModelSelect();
    $('#model-select').addEventListener('change', e => { if (e.target.value) setModel(e.target.value); });
    $('#reload-models').addEventListener('click', () => { state.models = null; fillModelSelect(); });
  }
  $('#chg-key')?.addEventListener('click', () => showSetup(true));
  $('#del-key')?.addEventListener('click', async e => {
    if (!e.target.dataset.sure) { e.target.dataset.sure = '1'; e.target.textContent = '한 번 더 누르면 키 삭제'; return; }
    state.apiKey = null;
    await db.setSetting('api_key', ''); await db.setSetting('own_provider', '');
    await useServer();
    bubble('bot', '저장된 API 키를 지웠어요.');
  });
  $('#export').addEventListener('click', exportCsv);
  $('#import-file').addEventListener('change', async e => {
    const f = e.target.files[0]; e.target.value = '';
    if (!f) return;
    const msg = $('#import-msg'); msg.hidden = false;
    try { const n = await importCsv(await f.text()); msg.textContent = `${n}건을 불러왔어요. (이미 있는 기록은 건너뜀)`; setTimeout(drawSettings, 1500); }
    catch (err) { msg.textContent = err.message; }
  });
  $('#wipe').addEventListener('click', async e => {
    if (!e.target.dataset.sure) { e.target.dataset.sure = '1'; e.target.textContent = '한 번 더 누르면 전부 삭제'; return; }
    await db.clear(); drawSettings();
  });
  drawAccount();
}

/* ---------------- 계정 · 서버 백업 ---------------- */
const fmtTime = iso => { if (!iso) return '아직 없음'; const d = new Date(iso); return `${d.toLocaleDateString('sv-SE')} ${d.toTimeString().slice(0, 5)}`; };

async function drawAccount(msg = '') {
  const el = $('#acct-card'); if (!el) return;
  const a = await account();
  const note = msg ? `<p class="muted small" id="acct-msg">${esc(msg)}</p>` : '';
  if (!a.loggedIn) {
    el.innerHTML = `<h3>계정 · 서버 백업</h3>
      <p class="muted small">로그인하면 기록을 서버에 저장해서 폰·PC 등 여러 기기에서 같이 쓰고, 앱을 지워도 되찾을 수 있어요. 로그인하지 않아도 앱은 지금처럼 쓸 수 있어요.</p>
      <input id="acct-id" placeholder="아이디 (영문 소문자·숫자 4~20자)" autocomplete="username" autocapitalize="none" spellcheck="false">
      <input id="acct-pw" type="password" placeholder="비밀번호 (6자 이상)" autocomplete="current-password">
      <div class="row2"><button class="btn primary" id="acct-login" type="button">로그인</button><button class="btn" id="acct-signup" type="button">가입하기</button></div>
      <p class="muted small">비밀번호를 잊으면 찾을 수 없어요. 꼭 기억해 두세요.</p>${note}`;
    const go = fn => async () => {
      const id = $('#acct-id').value, pw = $('#acct-pw').value;
      el.querySelectorAll('button').forEach(b => b.disabled = true);
      try { await fn(id, pw); await afterLogin(); }
      catch (e) { drawAccount(e.message); }
    };
    $('#acct-login').addEventListener('click', go(logIn));
    $('#acct-signup').addEventListener('click', go(signUp));
    return;
  }
  let c = null, err = '';
  try { c = await getConsent(); } catch (e) { err = e.message; }
  const on = consentOk(c) && await syncEnabled();
  el.innerHTML = `<h3>계정 · 서버 백업</h3>
    <p class="muted">아이디 <b>${esc(a.id)}</b></p>
    ${on ? `<p class="muted small">서버 저장 켜짐 · 마지막 동기화 ${esc(fmtTime(await db.getSetting('sync_last')))}</p>
            <button class="btn block" id="acct-sync" type="button">지금 동기화</button>`
         : `<p class="muted small">서버 저장 꺼짐 · 기록은 이 기기에만 있어요.</p>
            <button class="btn primary block" id="acct-agree" type="button">서버 저장 시작하기 (동의)</button>`}
    <button class="btn block" id="acct-logout" type="button">로그아웃</button>
    <a class="btn block" style="text-align:center;text-decoration:none;color:inherit" href="delete-account.html" target="_blank" rel="noopener">계정 삭제 요청</a>
    ${on ? `<button class="btn danger block" id="acct-withdraw" type="button">서버 저장 동의 철회 (서버 기록 삭제)</button>` : ''}
    ${err ? `<p class="muted small">${esc(err)}</p>` : ''}${note}`;
  $('#acct-sync')?.addEventListener('click', async e => {
    e.target.disabled = true; e.target.textContent = '동기화 중…';
    try { const r = await syncNow(); drawAccount(`동기화했어요. 받은 기록 ${r.pulled || 0}건 · 보낸 기록 ${r.pushed || 0}건`); refreshAfterSync(r); }
    catch (er) { drawAccount(er.message); }
  });
  $('#acct-agree')?.addEventListener('click', () => consentOk(c) ? afterLogin() : showConsent());
  $('#acct-logout').addEventListener('click', async e => {
    if (!e.target.dataset.sure) { e.target.dataset.sure = '1'; e.target.textContent = '한 번 더 누르면 로그아웃 (기기 기록은 남아요)'; return; }
    await logOut(); drawAccount('로그아웃했어요. 이 기기의 기록은 그대로 있어요.');
  });
  $('#acct-withdraw')?.addEventListener('click', async e => {
    if (!e.target.dataset.sure) { e.target.dataset.sure = '1'; e.target.textContent = '한 번 더 누르면 서버 기록 전부 삭제'; return; }
    e.target.disabled = true;
    try { await withdraw(); drawAccount('동의를 철회하고 서버 기록을 모두 삭제했어요. 이 기기의 기록은 그대로 있어요.'); }
    catch (er) { drawAccount(er.message); }
  });
}

async function afterLogin() {
  let c = null;
  try { c = await getConsent(); } catch (e) { return drawAccount(e.message); }
  if (consentOk(c)) {
    await db.setSetting('sync_enabled', '1');
    if (!(await askMerge())) return;
    drawAccount('로그인했어요. 서버 기록과 맞추는 중…');
    try { const r = await syncNow(); refreshAfterSync(r); drawAccount(`로그인했어요. 받은 기록 ${r.pulled || 0}건 · 보낸 기록 ${r.pushed || 0}건`); }
    catch (e) { drawAccount(e.message); }
  } else { drawAccount('로그인했어요.'); showConsent(); }
}

function refreshAfterSync(r) {
  if (!r || r.skipped) return;
  if (!$('#view-dash').hidden) refreshDash();
  if (r.pulled && !$('#view-settings').hidden) { const p = $('#data-count'); if (p) db.all().then(a => { p.textContent = p.textContent.replace(/\d+건/, a.length + '건'); }); }
}

// 이 기기에 기록이 있으면 계정에 합칠지 먼저 묻는다 (한 기기·한 계정에 한 번)
// true = 동기화 진행, false = 취소(로그아웃)
async function askMerge() {
  if (await isBound()) return true;
  const a = await account();
  const n = (await db.all()).length;
  if (!n) { await bind(); return true; }
  return new Promise(resolve => {
    const box = document.createElement('div');
    box.className = 'notice';
    box.innerHTML = `<div class="notice-box" role="dialog" aria-modal="true">
      <div class="notice-body">
        <h2>이 기기의 기록을 합칠까요?</h2>
        <p>이 기기에 기록이 <b>${n}건</b> 있어요. <b>${esc(a.id)}</b> 계정의 서버 기록과 어떻게 할지 골라 주세요.</p>
        <p class="muted small"><b>합치기</b>: 이 기기 기록 ${n}건을 계정에 올리고, 계정 기록도 이 기기로 받아요. 다른 사람이 쓰던 기기나 테스트 기록이 있으면 고르지 마세요.</p>
        <p class="muted small"><b>합치지 않기</b>: 이 기기 기록 ${n}건을 지우고 계정 기록만 받아요. 지우기 전에 필요하면 아래에서 CSV로 백업해 두세요.</p>
        <button class="btn block" id="m-backup" type="button">이 기기 기록 CSV로 백업</button>
      </div>
      <button class="btn primary block" id="m-merge" type="button">합치기 (${n}건 올리기)</button>
      <button class="btn block" id="m-replace" type="button" style="margin-top:8px">합치지 않기 (이 기기 기록 지우고 계정 기록 받기)</button>
      <button class="btn block" id="m-cancel" type="button" style="margin-top:8px">취소 (로그아웃)</button></div>`;
    document.body.appendChild(box);
    const done = v => { box.remove(); resolve(v); };
    box.querySelector('#m-backup').addEventListener('click', exportCsv);
    box.querySelector('#m-merge').addEventListener('click', async () => { await bind(); done(true); });
    box.querySelector('#m-replace').addEventListener('click', async e => {
      if (!e.target.dataset.sure) { e.target.dataset.sure = '1'; e.target.textContent = `한 번 더 누르면 이 기기 기록 ${n}건 삭제`; return; }
      await db.clear({ sync: true }); // 서버에는 삭제를 보내지 않음
      await bind(); done(true);
    });
    box.querySelector('#m-cancel').addEventListener('click', async () => { await logOut(); drawAccount('로그인을 취소했어요. 이 기기의 기록은 그대로 있어요.'); done(false); });
  });
}

function showConsent() {
  const box = document.createElement('div');
  box.className = 'notice';
  box.innerHTML = `<div class="notice-box" role="dialog" aria-modal="true">
    <div class="notice-body">
      <h2>서버 저장 동의</h2>
      <p>여러 기기에서 기록을 함께 쓰고 백업하려면 운동 기록을 서버에 저장해야 합니다. 동의하지 않으셔도 앱은 기기 저장 방식으로 계속 이용하실 수 있습니다.</p>
      <label class="agree"><input type="checkbox" id="c-store"> <span><b>[필수] 운동 기록 서버 저장</b><br>
        항목: 운동 날짜, 종목, 운동 시간, 결과, 세부 수치, 메모 · 목적: 여러 기기 동기화 및 백업 · 보관: 동의 철회 시까지 (철회 즉시 서버에서 삭제)</span></label>
      <label class="agree"><input type="checkbox" id="c-health"> <span><b>[필수] 건강 관련 정보 처리</b><br>
        운동 기록과 컨디션 메모 등은 건강 관련 정보에 해당할 수 있습니다. 위 목적 범위에서만 처리하며, 다른 곳에 제공하지 않습니다.</span></label>
      <p class="muted small">동의는 [설정 → 계정 · 서버 백업]에서 언제든 철회할 수 있습니다.</p>
    </div>
    <button class="btn primary block" id="c-ok" disabled>동의하고 서버 저장 시작</button>
    <button class="btn block" id="c-later" style="margin-top:8px">나중에</button></div>`;
  document.body.appendChild(box);
  const upd = () => { box.querySelector('#c-ok').disabled = !(box.querySelector('#c-store').checked && box.querySelector('#c-health').checked); };
  box.querySelector('#c-store').addEventListener('change', upd);
  box.querySelector('#c-health').addEventListener('change', upd);
  box.querySelector('#c-later').addEventListener('click', () => box.remove());
  box.querySelector('#c-ok').addEventListener('click', async e => {
    e.target.disabled = true; e.target.textContent = '저장 중…';
    try {
      await agree(); box.remove();
      if (!(await askMerge())) return;
      drawAccount('서버 저장을 시작했어요. 기록을 맞추는 중…');
      const r = await syncNow(); refreshAfterSync(r);
      drawAccount(`서버 저장을 시작했어요. 받은 기록 ${r.pulled || 0}건 · 보낸 기록 ${r.pushed || 0}건`);
    } catch (er) { box.remove(); drawAccount(er.message); }
  });
}

async function setModel(m) {
  state.model = m; await db.setSetting('model', m);
  const inp = $('#model'); if (inp) inp.value = m;
  const sel = $('#model-select'); if (sel && [...sel.options].some(o => o.value === m)) sel.value = m;
}

const price = v => v === 0 ? '0' : v < 0.1 ? v.toFixed(3) : v < 10 ? v.toFixed(2) : v.toFixed(0);
async function fillModelSelect() {
  const sel = $('#model-select'); if (!sel) return;
  try {
    if (!state.models) state.models = await listVisionModels();
    const opt = m => `<option value="${esc(m.id)}">${esc(m.name)} — ${m.free ? '무료' : `$${price(m.inP)} / $${price(m.outP)}`}</option>`;
    const free = state.models.filter(m => m.free), paid = state.models.filter(m => !m.free);
    sel.innerHTML = `<option value="">모델 고르기</option>`
      + (free.length ? `<optgroup label="무료 (테스트용)">${free.map(opt).join('')}</optgroup>` : '')
      + `<optgroup label="유료">${paid.map(opt).join('')}</optgroup>`;
    if (state.model) sel.value = state.model;
  } catch (e) { sel.innerHTML = `<option value="">${esc(e.message)}</option>`; }
}

async function exportCsv() {
  const rows = await db.all();
  const cols = ['id', 'date', 'exercise_type', 'exercise_name', 'duration_min', 'result_summary', 'detail_json', 'memo', 'created_at', 'updated_at'];
  const q = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const csv = '﻿' + [cols.join(','), ...rows.map(r => cols.map(c => q(r[c])).join(','))].join('\n');
  try {
    if (navigator.share && isNative()) {
      const file = new File([csv], 'workout_logs.csv', { type: 'text/csv' });
      if (navigator.canShare?.({ files: [file] })) return navigator.share({ files: [file] });
    }
  } catch {}
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
  a.download = 'workout_logs.csv'; a.click();
}

function parseCsv(text) {
  const rows = []; let row = [], cell = '', q = false;
  text = text.replace(/^\uFEFF/, '');
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) { if (ch === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += ch; }
    else if (ch === '"') q = true;
    else if (ch === ',') { row.push(cell); cell = ''; }
    else if (ch === '\n' || ch === '\r') { if (ch === '\r' && text[i + 1] === '\n') i++; row.push(cell); rows.push(row); row = []; cell = ''; }
    else cell += ch;
  }
  if (cell || row.length) { row.push(cell); rows.push(row); }
  return rows.filter(r => r.some(c => c !== ''));
}

async function importCsv(text) {
  const [head, ...body] = parseCsv(text);
  if (!head || !head.includes('date') || !head.includes('exercise_type')) throw new Error('이 앱에서 내보낸 CSV 파일이 아니에요.');
  const ix = k => head.indexOf(k);
  const have = new Set((await db.all()).map(r => [r.date, r.exercise_type, r.exercise_name || '', r.result_summary || ''].join('|')));
  let n = 0;
  for (const c of body) {
    const g = k => (ix(k) >= 0 ? c[ix(k)] : '') || null;
    const rec = { date: g('date'), exercise_type: g('exercise_type'), exercise_name: g('exercise_name'),
      duration_min: g('duration_min') == null ? null : Number(g('duration_min')), result_summary: g('result_summary'),
      detail_json: (() => { try { return JSON.parse(g('detail_json') || '{}'); } catch { return {}; } })(), memo: g('memo') };
    if (!rec.date || !rec.exercise_type) continue;
    const key = [rec.date, rec.exercise_type, rec.exercise_name || '', rec.result_summary || ''].join('|');
    if (have.has(key)) continue;
    await db.insert(rec); have.add(key); n++;
  }
  return n;
}

async function insertSample() {
  const d = n => { const x = new Date(); x.setDate(x.getDate() - n); return x.toLocaleDateString('sv-SE'); };
  const S = [
    [20, '러닝', '야외 러닝', 30, '4km 무휴식', { distance_km: 4.0, pace_sec_per_km: 450, avg_heart_rate: 165, cadence: 150, continuous: true }, null],
    [17, '헬스', '풀업', 15, '보조 6/5/4회', { sets: [{ weight_kg: 0, reps: 6 }, { weight_kg: 0, reps: 5 }, { weight_kg: 0, reps: 4 }], assistance: 'band' }, null],
    [14, '러닝', '야외 러닝', 32, '4.5km 무휴식', { distance_km: 4.5, pace_sec_per_km: 427, avg_heart_rate: 170, max_heart_rate: 182, cadence: 152, continuous: true }, null],
    [12, '클라이밍', '볼더링', 120, '파랑3 빨강1', { gym: '더클라이밍 성수', problems: { blue: 3, red: 1 } }, '전완근 펌핑'],
    [10, '헬스', '스쿼트', 20, '20kg 6/5/4회', { sets: [{ weight_kg: 20, reps: 6 }, { weight_kg: 20, reps: 5 }, { weight_kg: 20, reps: 4 }], assistance: null }, null],
    [7, '러닝', '야외 러닝', 34, '5km 무휴식', { distance_km: 5.0, pace_sec_per_km: 408, avg_heart_rate: 168, max_heart_rate: 181, cadence: 155, continuous: true }, '허벅지가 먼저 힘들었음'],
    [5, '클라이밍', '볼더링', 120, '파랑4 빨강2', { gym: '더클라이밍 성수', problems: { blue: 4, red: 2 } }, null],
    [3, '헬스', '스쿼트', 22, '25kg 6/6/5회', { sets: [{ weight_kg: 25, reps: 6 }, { weight_kg: 25, reps: 6 }, { weight_kg: 25, reps: 5 }], assistance: null }, null],
    [1, '러닝', '야외 러닝', 40, '6km 무휴식', { distance_km: 6.0, pace_sec_per_km: 400, avg_heart_rate: 166, max_heart_rate: 179, cadence: 157, continuous: true }, '컨디션 좋음'],
  ];
  for (const [n, t, nm, dur, sum, det, memo] of S)
    await db.insert({ date: d(n), exercise_type: t, exercise_name: nm, duration_min: dur, result_summary: sum, detail_json: det, memo });
}

/* ---------------- API 키 입력 ---------------- */
function drawSetupProvider() {
  const pv = PROVIDERS[state.setupProvider];
  document.querySelectorAll('[data-prov]').forEach(b => b.classList.toggle('on', b.dataset.prov === state.setupProvider));
  $('#key').placeholder = pv.keyPrefix + '...';
  $('#key-steps').innerHTML = state.setupProvider === 'openrouter'
    ? `<li>openrouter.ai 접속 → 로그인 (구글 계정 가능)</li><li>Keys → Create Key</li><li>sk-or- 로 시작하는 키를 복사해 아래에 붙여넣기</li><li>무료 모델로 시험해 볼 수 있고, 유료 모델은 Credits 충전이 필요해요</li>`
    : `<li>platform.openai.com 접속 → 로그인</li><li>API keys → Create new secret key</li><li>sk- 로 시작하는 키를 복사해 아래에 붙여넣기</li><li>Billing에서 크레딧 충전이 필요해요 (ChatGPT 구독과 별개)</li>`;
}

function showSetup(canCancel = false) {
  state.setupProvider = state.provider === 'server' ? 'openrouter' : state.provider;
  drawSetupProvider();
  $('#setup').hidden = false;
  $('#setup-cancel').hidden = !canCancel;
  $('#key').value = '';
  $('#setup-err').hidden = true;
}

async function saveKey() {
  const k = $('#key').value.trim();
  const err = $('#setup-err');
  const prov = state.setupProvider, pv = PROVIDERS[prov];
  if (!k.startsWith(pv.keyPrefix)) { err.textContent = `${pv.label} API 키는 ${pv.keyPrefix} 로 시작해요.`; err.hidden = false; return; }
  $('#save-key').disabled = true; $('#save-key').textContent = '확인 중…';
  try {
    await validateKey(prov, k);
    const changed = prov !== state.provider;
    state.provider = prov; state.apiKey = k;
    await db.setSetting('provider', prov); await db.setSetting('own_provider', prov); await db.setSetting('api_key', k);
    if (changed || !state.model) {
      let m = pv.defaultModel;
      if (prov === 'openrouter') {
        try { state.models = await listVisionModels(); m = pickDefaultModel(state.models); } catch { m = ''; }
      }
      await setModel(m);
    }
    $('#setup').hidden = true;
    drawQuota();
    if (!$('#view-settings').hidden) drawSettings();
    bubble('bot', `${esc(pv.label)}로 연결했어요.${state.model ? ` 모델: ${esc(state.model)}` : ' 설정 탭에서 모델을 골라 주세요.'}`);
  } catch (e) { err.textContent = e.message; err.hidden = false; }
  finally { $('#save-key').disabled = false; $('#save-key').textContent = '저장'; }
}

async function useServer() {
  state.provider = 'server'; await db.setSetting('provider', 'server');
  state.remaining = await remainingToday();
  drawQuota();
  if (!$('#view-settings').hidden) drawSettings();
  bubble('bot', '기본 (무료) AI로 바꿨어요.');
}

// 채팅 입력창 위 "오늘 남은 횟수" 표시
function drawQuota() {
  const el = $('#quota'); if (!el) return;
  el.hidden = state.provider !== 'server' || state.remaining == null;
  el.textContent = state.remaining === 0 ? '오늘 무료 횟수를 다 썼어요 · 0시에 다시 차요' : `오늘 남은 무료 횟수 ${state.remaining}회`;
}

/* ---------------- 시작 ---------------- */
async function main() {
  await db.init();
  if (db.fallback) console.warn('storage fallback:', db.initError);
  state.apiKey = await db.getSetting('api_key');
  // 예전 버전에서 키를 넣어 둔 사람은 그 키를 계속 쓰고, 처음 쓰는 사람은 기본(서버) 모드
  state.provider = (await db.getSetting('provider')) || (state.apiKey ? 'openai' : 'server');
  if (state.apiKey && !(await db.getSetting('own_provider')) && state.provider !== 'server') await db.setSetting('own_provider', state.provider);
  state.model = (await db.getSetting('model')) ?? (state.provider === 'openai' ? DEFAULT_MODEL : '');
  state.remaining = await remainingToday();
  // 예전 버전이 고른 쓸 수 없는 모델(예: ...:batch)은 기본 모델로 바로잡기
  if (state.provider === 'openrouter' && state.model && !usableModelId(state.model)) {
    state.model = state.model.split(':')[0];
    await db.setSetting('model', state.model);
  }

  document.querySelectorAll('.tab').forEach(t => t.addEventListener('click', () => show(t.dataset.view)));
  $('#composer').addEventListener('submit', e => { e.preventDefault(); const v = $('#input').value; $('#input').value = ''; state.imagesOnlyText = !v.trim() && state.images.length > 0; send(v); });
  // 안드로이드 앱(WebView)은 고른 사진의 읽기 권한이 금방 사라질 수 있어서,
  // 고르는 즉시 내용을 메모리로 복사해 두고 그다음에 입력칸을 비운다.
  $('#photo').addEventListener('change', async e => {
    const input = e.target;
    const picked = [...input.files].filter(f => /^image\//.test(f.type) || !f.type).slice(0, state.maxImages - state.images.length);
    const copies = [], failed = [];
    for (const f of picked) {
      try { copies.push(new File([await f.arrayBuffer()], f.name || 'photo.jpg', { type: f.type || 'image/jpeg' })); }
      catch (err) { failed.push(`${f.name || '사진'}: ${err?.message || err}`); }
    }
    input.value = '';
    state.images = [...state.images, ...copies].slice(0, state.maxImages);
    drawAttach();
    if (failed.length) bubble('bot err', `사진을 가져오지 못했어요. 갤러리 앱에서 다시 골라 주세요.<br><small>${esc(failed.join(' / '))}</small>`);
  });
  $('#attach').addEventListener('click', e => { const b = e.target.closest('[data-rm]'); if (!b) return; state.images.splice(Number(b.dataset.rm), 1); drawAttach(); });
  document.querySelector('.photo-hint').addEventListener('click', () => $('#photo').click());
  $('#save-key').addEventListener('click', saveKey);
  $('#prov').addEventListener('click', e => { const b = e.target.closest('[data-prov]'); if (!b) return; state.setupProvider = b.dataset.prov; drawSetupProvider(); });
  $('#setup-cancel').addEventListener('click', () => { $('#setup').hidden = true; });
  $('#modal').addEventListener('click', e => { if (e.target.id === 'modal') { /* 바깥 탭으로 닫지 않음 */ } });
  document.querySelectorAll('.hint:not(.photo-hint)').forEach(h => h.addEventListener('click', () => { $('#input').value = h.textContent; $('#input').focus(); }));

  bubble('bot', '오늘 한 운동을 편하게 말해 주세요. 러닝앱이나 클라이밍 기록 공유 사진을 올려도 돼요.<br>예: "오늘 야외에서 5km 34분 뛰었어. 페이스 6분48초, 허벅지가 먼저 힘들었음"');
  show('chat');
  drawQuota();
  setupPwa();
  showNotice();
  watchChanges(r => { refreshAfterSync(r); if (!$('#view-settings').hidden) drawAccount(r?.error || ''); });
  (async () => {
    if ((await db.getSetting('sync_enabled')) === '1' && (await account()).loggedIn && !(await isBound())) {
      if (!(await askMerge())) return;
    }
    refreshAfterSync(await syncNow());
  })().catch(e => console.warn('sync', e));
}

/* ---------------- 공지 ---------------- */
// 내용을 바꾸면 NOTICE_VERSION을 올려야 닫았던 사람에게도 다시 보임
const NOTICE_VERSION = '2026-10-10';
const NOTICE_HTML = `
  <h2>Caldron AI 이용 안내</h2>
  <h4>AI 데이터 처리</h4>
  <p>무료 AI 기능은 Google Gemini 무료 등급으로 제공됩니다. 입력하신 채팅, 사진 및 최근 기록은 Google로 전송되며, AI 학습 및 서비스 개선에 활용될 수 있습니다.</p>
  <h4>민감정보 주의</h4>
  <p>얼굴, 실명, 연락처 등 개인을 식별할 수 있는 정보는 입력하지 마시기 바랍니다.</p>
  <h4>기록 저장</h4>
  <p>로그인 시 기록이 서버에 저장될 수 있으며, 이에 대해서는 별도로 동의를 받습니다. 로그인하지 않거나 서버 저장에 동의하지 않으신 경우, 기록은 기기에만 보관됩니다. [설정 → CSV 백업]으로 정기적으로 백업해 주시기 바랍니다.</p>
  <h4>이용 한도</h4>
  <p>무료 AI 기능은 이용 횟수에 제한이 있습니다. 제한 없이 이용하시려면 [설정 → AI 연결 방식]에서 개인 API 키를 입력해 주시기 바랍니다. (요금은 본인 계정에 청구됩니다.)</p>
  <h4>결과 확인</h4>
  <p>AI 분석 결과에 오류가 있을 수 있으니, 저장 전에 내용을 확인해 주시기 바랍니다.</p>`;

async function showNotice() {
  let seen = null;
  try { seen = await db.getSetting('notice_seen'); } catch {}
  if (seen === NOTICE_VERSION) return;
  const box = document.createElement('div');
  box.className = 'notice';
  box.innerHTML = `<div class="notice-box" role="dialog" aria-modal="true">
    <div class="notice-body">${NOTICE_HTML}</div>
    <button class="btn primary block" id="notice-x">닫기</button></div>`;
  document.body.appendChild(box);
  box.querySelector('#notice-x').addEventListener('click', async () => {
    box.remove();
    try { await db.setSetting('notice_seen', NOTICE_VERSION); } catch {}
  });
}

// 웹앱(아이폰·브라우저)으로 열었을 때: 오프라인 보관 + 홈 화면 추가 안내
function setupPwa() {
  if (isNative()) return;
  if ('serviceWorker' in navigator && location.protocol === 'https:') navigator.serviceWorker.register('sw.js').catch(() => {});
  // Play 스토어 앱(TWA)으로 열면 referrer가 android-app://… — 첫 화면에서만 보이므로 기억해 둔다
  let twa = document.referrer.startsWith('android-app://');
  try { if (twa) sessionStorage.setItem('wl_twa', '1'); else twa = sessionStorage.getItem('wl_twa') === '1'; } catch {}
  const standalone = twa || window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
  const ua = navigator.userAgent;
  const ios = /iPhone|iPad|iPod/i.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  let dismissed = false; try { dismissed = localStorage.getItem('wl_install_x') === '1'; } catch {}
  if (standalone || dismissed) return;
  if (ios) {
    if (!/Safari/i.test(ua) || /CriOS|FxiOS|EdgiOS|KAKAOTALK|NAVER|Instagram|FBAN/i.test(ua))
      $('#install-how').innerHTML = '<b>Safari</b>로 이 주소를 열어야 홈 화면에 추가할 수 있어요';
    $('#install').hidden = false;
  } else if (/Android/i.test(ua)) {
    $('#install-how').innerHTML = 'Chrome 메뉴 ⋮ → <b>홈 화면에 추가</b> (또는 앱 설치)';
    $('#install').hidden = false;
  }
  $('#install-x').addEventListener('click', () => { $('#install').hidden = true; try { localStorage.setItem('wl_install_x', '1'); } catch {} });
}

window.__app = { db, state, send, insertSample, show }; // 디버그/테스트용
main().catch(e => {
  console.error(e);
  const d = document.createElement('p');
  d.style.cssText = 'margin:12px;padding:12px;border-radius:10px;background:#fee;color:#900;font-size:14px';
  d.textContent = '앱을 시작하지 못했어요: ' + (e?.message || e);
  document.body.prepend(d);
});
