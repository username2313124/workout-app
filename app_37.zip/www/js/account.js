// 계정(아이디·비밀번호) + 서버 저장 동의 + 기록 동기화
// - 아이디는 내부에서 "아이디@users.caldron.app" 형식으로 바꿔 Supabase 이메일 로그인에 쓴다 (메일은 보내지 않음)
// - 서버 저장은 동의한 로그인 사용자만. 서버 테이블: cloud_logs, consents (RLS로 본인 것만)
import { SUPABASE_URL } from './config.js';
import { db } from './db.js';
import { AUTH, base, authPost, getToken } from './server.js';

export const POLICY_VERSION = '2026-10-12';
const REST = `${SUPABASE_URL}/rest/v1`;
const DOMAIN = 'users.caldron.app';

export const ID_RULE = /^[a-z0-9_]{4,20}$/;
const idToEmail = id => `${id}@${DOMAIN}`;

function claims(token) {
  try { return JSON.parse(decodeURIComponent(escape(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))))); } catch { return {}; }
}

// 지금 로그인 상태: { loggedIn, id, userId }
export async function account() {
  let s = null;
  try { s = JSON.parse((await db.getSetting('sb_session')) || 'null'); } catch {}
  if (!s?.access_token) return { loggedIn: false };
  const c = claims(s.access_token);
  if (c.is_anonymous || !c.email) return { loggedIn: false, userId: c.sub };
  return { loggedIn: true, id: String(c.email).split('@')[0], userId: c.sub };
}

function friendly(err, fallback) {
  const m = String(err?.message || err || '');
  if (/already|registered|exists/i.test(m)) return '이미 있는 아이디예요. 다른 아이디를 쓰거나 로그인해 주세요.';
  if (/invalid login|credentials/i.test(m)) return '아이디 또는 비밀번호가 맞지 않아요.';
  if (/password/i.test(m) && /(6|short|weak|characters)/i.test(m)) return '비밀번호는 6자 이상으로 해 주세요.';
  if (/signups not allowed|signup.*disabled/i.test(m)) return '지금은 가입을 받지 않아요. (서버 설정: Allow new users to sign up)';
  if (/confirm/i.test(m)) return '서버 설정에서 Confirm email 을 꺼 주세요.';
  if (/rate|too many/i.test(m)) return '잠시 후 다시 시도해 주세요. (요청이 너무 많아요)';
  return `${fallback} (${m})`;
}

export async function signUp(id, pw) {
  id = id.trim().toLowerCase();
  if (!ID_RULE.test(id)) throw new Error('아이디는 영문 소문자·숫자·밑줄(_)로 4~20자예요.');
  if ((pw || '').length < 6) throw new Error('비밀번호는 6자 이상으로 해 주세요.');
  try { await authPost('/signup', { email: idToEmail(id), password: pw }); }
  catch (e) {
    // 세션 없이 응답(이메일 인증 대기)이면 access_token 이 없어 여기로 온다
    throw new Error(friendly(e, '가입하지 못했어요.'));
  }
  return account();
}

export async function logIn(id, pw) {
  id = id.trim().toLowerCase();
  try { await authPost('/token?grant_type=password', { email: idToEmail(id), password: pw }); }
  catch (e) { throw new Error(friendly(e, '로그인하지 못했어요.')); }
  return account();
}

export async function logOut() {
  try {
    const s = JSON.parse((await db.getSetting('sb_session')) || 'null');
    if (s?.access_token) await fetch(`${AUTH}/logout`, { method: 'POST', headers: { ...base, Authorization: `Bearer ${s.access_token}` } });
  } catch {}
  await db.setSetting('sb_session', '');
  await db.setSetting('sync_enabled', '');
  await db.setSetting('sync_deleted', '[]');
  await db.setSetting('sync_last', '');
}

async function rest(method, path, body, extra = {}) {
  const call = async force => fetch(`${REST}/${path}`, {
    method,
    headers: { ...base, Authorization: `Bearer ${await getToken(force)}`, ...extra },
    body: body == null ? undefined : JSON.stringify(body),
  });
  let res = await call(false);
  if (res.status === 401) res = await call(true);
  const text = await res.text();
  let j = null; try { j = text ? JSON.parse(text) : null; } catch {}
  if (!res.ok) {
    const m = j?.message || j?.hint || text || `HTTP ${res.status}`;
    if (/relation .* does not exist|could not find the table/i.test(m)) throw new Error('서버에 cloud_logs / consents 테이블이 없어요. SQL을 먼저 실행해 주세요.');
    throw new Error(`서버 저장 오류: ${m}`);
  }
  return j;
}

/* ---------- 동의 ---------- */
export async function getConsent() {
  const a = await account(); if (!a.loggedIn) return null;
  const rows = await rest('GET', `consents?select=*&user_id=eq.${a.userId}`);
  return rows?.[0] || null;
}
export const consentOk = c => !!(c && c.storage_agreed_at && c.health_agreed_at && !c.withdrawn_at);

export async function agree() {
  const a = await account(); if (!a.loggedIn) throw new Error('먼저 로그인해 주세요.');
  const t = new Date().toISOString();
  await rest('POST', 'consents?on_conflict=user_id', [{ user_id: a.userId, storage_agreed_at: t, health_agreed_at: t, policy_version: POLICY_VERSION, withdrawn_at: null }],
    { Prefer: 'resolution=merge-duplicates,return=minimal' });
  await db.setSetting('sync_enabled', '1');
  await db.setSetting('sync_deleted', '[]');
}

// 동의 철회: 서버 기록 전부 삭제 + 동의 철회 시각 기록. 기기 안 기록은 그대로
export async function withdraw() {
  const a = await account(); if (!a.loggedIn) throw new Error('먼저 로그인해 주세요.');
  await rest('DELETE', `cloud_logs?user_id=eq.${a.userId}`, null, { Prefer: 'return=minimal' });
  await rest('POST', 'consents?on_conflict=user_id', [{ user_id: a.userId, storage_agreed_at: null, health_agreed_at: null, policy_version: POLICY_VERSION, withdrawn_at: new Date().toISOString() }],
    { Prefer: 'resolution=merge-duplicates,return=minimal' });
  await db.setSetting('sync_enabled', '');
  await db.setSetting('sync_deleted', '[]');
  await db.setSetting('sync_last', '');
}

/* ---------- 동기화 ---------- */
export const syncEnabled = async () => (await db.getSetting('sync_enabled')) === '1' && (await account()).loggedIn;

const ts = v => Date.parse(v || 0) || 0;
const toLocal = r => ({ uid: r.uid, date: r.date, exercise_type: r.exercise_type, exercise_name: r.exercise_name, duration_min: r.duration_min == null ? null : Number(r.duration_min),
  result_summary: r.result_summary, detail_json: r.detail_json || {}, memo: r.memo, updated_at: new Date(ts(r.updated_at)).toISOString() });
const toRemote = (r, userId) => ({ user_id: userId, uid: r.uid, date: r.date, exercise_type: r.exercise_type, exercise_name: r.exercise_name ?? null,
  duration_min: r.duration_min ?? null, result_summary: r.result_summary ?? null, detail_json: r.detail || {}, memo: r.memo ?? null,
  deleted: false, updated_at: new Date(ts(r.updated_at) || Date.now()).toISOString() });

async function pullAll(userId) {
  const out = [];
  for (let off = 0; ; off += 1000) {
    const page = await rest('GET', `cloud_logs?select=*&user_id=eq.${userId}&order=uid&limit=1000&offset=${off}`);
    out.push(...(page || []));
    if (!page || page.length < 1000) return out;
  }
}

let running = null, again = false;
// 서버와 기기 기록 맞추기: 더 최근에 바뀐 쪽을 따른다. 삭제도 전달.
export async function syncNow() {
  if (running) { again = true; return running; }
  running = (async () => {
    try {
      if (!(await syncEnabled())) return { skipped: true };
      const { userId } = await account();
      await db.ensureUids();
      let deleted = []; try { deleted = JSON.parse((await db.getSetting('sync_deleted')) || '[]'); } catch {}
      const delSet = new Set(deleted);
      const remote = await pullAll(userId);
      const rmap = new Map(remote.map(r => [r.uid, r]));
      let local = await db.all();
      const lmap = new Map(local.map(r => [r.uid, r]));
      let pulled = 0;
      // 1) 서버 → 기기
      for (const r of remote) {
        if (delSet.has(r.uid)) continue; // 이 기기에서 지운 기록 → 아래에서 서버에도 삭제 전달
        const l = lmap.get(r.uid);
        if (r.deleted) { if (l) { await db.remove(l.id, { sync: true }); pulled++; } continue; }
        if (!l) { await db.insert(toLocal(r), { sync: true }); pulled++; }
        else if (ts(r.updated_at) > ts(l.updated_at)) { await db.update(l.id, toLocal(r), { sync: true }); pulled++; }
      }
      // 2) 기기 → 서버 (서버에 없거나 기기 쪽이 더 최근)
      local = await db.all();
      const up = local.filter(l => { const r = rmap.get(l.uid); return !r || (!r.deleted && ts(l.updated_at) > ts(r.updated_at)); })
        .map(l => toRemote(l, userId));
      for (const uid of delSet) {
        const r = rmap.get(uid);
        if (r && !r.deleted) up.push({ ...r, deleted: true, updated_at: new Date().toISOString() });
      }
      for (let i = 0; i < up.length; i += 200)
        await rest('POST', 'cloud_logs?on_conflict=user_id,uid', up.slice(i, i + 200), { Prefer: 'resolution=merge-duplicates,return=minimal' });
      await db.setSetting('sync_deleted', '[]');
      await db.setSetting('sync_last', new Date().toISOString());
      return { pulled, pushed: up.length };
    } finally {
      running = null;
      if (again) { again = false; setTimeout(() => syncNow().catch(() => {}), 500); }
    }
  })();
  return running;
}

// 기록이 바뀌면 (삭제는 uid 를 모아 두고) 잠시 뒤 동기화
let timer = null;
export function watchChanges(onSynced) {
  db.onChange = async (kind, info) => {
    if (!(await syncEnabled())) return;
    if (kind === 'remove' && info?.uids?.length) {
      let d = []; try { d = JSON.parse((await db.getSetting('sync_deleted')) || '[]'); } catch {}
      await db.setSetting('sync_deleted', JSON.stringify([...new Set([...d, ...info.uids])]));
    }
    clearTimeout(timer);
    timer = setTimeout(() => syncNow().then(r => onSynced?.(r)).catch(e => onSynced?.({ error: e.message })), 1500);
  };
}
