// 파워BI처럼: 컬럼 값이 그대로 슬라이서가 되고, 선택에 따라 차트가 바뀐다
import { extractMetrics, metricKeys, label, aggKind, fmtValue, seriesColor, subLabel, intervalsOf, fmtPace } from './metrics.js';
import { lineChart, barChart, hBarChart, multiLineChart, intervalBars } from './charts.js';

const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

export const slicer = { period: '30', type: '', name: '' };

const PERIODS = [['7', '7일'], ['30', '30일'], ['90', '90일'], ['365', '1년'], ['all', '전체']];

function addDays(iso, n) {
  const d = new Date(iso + 'T00:00:00');
  d.setDate(d.getDate() + n);
  return d.toLocaleDateString('sv-SE');
}

function groupByDate(recs, key) {
  const g = {};
  for (const r of recs) {
    const v = key === '__count' ? 1 : extractMetrics(r)[key];
    if (v == null) continue;
    (g[r.date] ||= []).push(v);
  }
  const kind = key === '__count' ? 'sum' : aggKind(key);
  return Object.keys(g).sort().map(x => ({
    x, y: kind === 'avg' ? g[x].reduce((a, b) => a + b, 0) / g[x].length : g[x].reduce((a, b) => a + b, 0),
  }));
}

function countBy(recs, field, valueFn = () => 1) {
  const m = {};
  for (const r of recs) { const k = r[field] || '(미지정)'; m[k] = (m[k] || 0) + (valueFn(r) || 0); }
  return Object.entries(m).map(([label, value]) => ({ label, value })).sort((a, b) => b.value - a.value);
}

function chips(name, items, current) {
  return items.map(([v, t]) =>
    `<button class="chip ${v === current ? 'on' : ''}" data-slicer="${name}" data-value="${esc(v)}">${esc(t)}</button>`).join('');
}

function card(title, body, sub = '') {
  return `<section class="card"><div class="card-h"><h3>${esc(title)}</h3>${sub ? `<span class="muted">${esc(sub)}</span>` : ''}</div>${body}</section>`;
}

export function renderDashboard(el, all, today, onEdit) {
  const types = [...new Set(all.map(r => r.exercise_type))];
  if (slicer.type && !types.includes(slicer.type)) { slicer.type = ''; slicer.name = ''; }

  const from = slicer.period === 'all' ? '0000-00-00' : addDays(today, -(Number(slicer.period) - 1));
  const inPeriod = all.filter(r => r.date >= from && r.date <= today);
  const byType = slicer.type ? inPeriod.filter(r => r.exercise_type === slicer.type) : inPeriod;
  const names = [...new Set((slicer.type ? all.filter(r => r.exercise_type === slicer.type) : all).map(r => r.exercise_name).filter(Boolean))];
  if (slicer.name && !names.includes(slicer.name)) slicer.name = '';
  const recs = slicer.name ? byType.filter(r => r.exercise_name === slicer.name) : byType;

  const totalMin = recs.reduce((a, r) => a + (Number(r.duration_min) || 0), 0);
  const days = new Set(recs.map(r => r.date)).size;

  let html = `
  <div class="slicers">
    <div class="slicer-row"><span class="slicer-l">기간</span><div class="chips">${chips('period', PERIODS, slicer.period)}</div></div>
    <div class="slicer-row"><span class="slicer-l">운동종류</span><div class="chips">${chips('type', [['', '전체'], ...types.map(t => [t, t])], slicer.type)}</div></div>
    <div class="slicer-row"><span class="slicer-l">세부운동</span>
      <select data-slicer="name"><option value="">전체</option>${names.map(n => `<option ${n === slicer.name ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></div>
  </div>
  <div class="kpis">
    <div class="kpi"><b>${recs.length}</b><span>기록</span></div>
    <div class="kpi"><b>${days}</b><span>운동한 날</span></div>
    <div class="kpi"><b>${totalMin >= 60 ? (totalMin / 60).toFixed(1) + 'h' : Math.round(totalMin) + 'm'}</b><span>총 운동시간</span></div>
  </div>`;

  if (!all.length) {
    el.innerHTML = html + `<div class="empty big">아직 기록이 없어요.<br>채팅 탭에서 오늘 한 운동을 말해 보세요.</div>`;
    return bind(el, all, today, onEdit);
  }

  if (!slicer.type) {
    html += card('날짜별 운동시간', barChart(groupByDate(recs, 'duration_min').map(p => ({ label: p.x, value: p.y })), v => Math.round(v) + '분', { dateLabels: true }), '분');
    html += card('운동종류별 횟수', hBarChart(countBy(recs, 'exercise_type'), v => v + '회'));
    html += card('운동종류별 운동시간', hBarChart(countBy(recs, 'exercise_type', r => Number(r.duration_min)), v => Math.round(v) + '분'));
  } else {
    if (!slicer.name && names.length > 1) html += card('세부운동별 횟수', hBarChart(countBy(recs, 'exercise_name'), v => v + '회'));
    const keys = metricKeys(recs);
    // "problems.blue", "problems.red" 처럼 같은 묶음의 하위 지표는 한 차트에 색깔별 선으로 겹친다
    const groups = {};
    for (const k of keys) { const m = k.match(/^([^.]+)\.([^.]+)$/); if (m && !/_(sum|max)$/.test(k)) (groups[m[1]] ||= []).push(m[2]); }
    const grouped = new Set();
    for (const [parent, subs] of Object.entries(groups)) {
      if (subs.length < 2) continue;
      // 그날 기록에 없던 색은 0개로 본다 (합계형 지표)
      const days = [...new Set(recs.filter(r => Object.keys(extractMetrics(r)).some(k => k.startsWith(parent + '.'))).map(r => r.date))].sort();
      const series = subs.map((sub, i) => {
        const key = `${parent}.${sub}`, by = Object.fromEntries(groupByDate(recs, key).map(p => [p.x, p.y]));
        return { name: subLabel(sub), color: seriesColor(sub, i), points: days.map(x => ({ x, y: by[x] ?? 0 })) };
      });
      subs.forEach(sub => grouped.add(`${parent}.${sub}`));
      const title = parent === 'problems' ? '색깔별 완등 문제 수' : parent === 'segdist' ? '뛰기·걷기 구간 평균 거리(km)' : `${parent.replace(/_/g, ' ')} 항목별`;
      html += card(title, multiLineChart(series, v => parent === 'segdist' ? v.toFixed(1) : fmtValue(parent, v), { integer: parent !== 'segdist' }));
    }
    for (const k of keys) {
      if (grouped.has(k) || k === 'interval_runs' || k === 'best_pace_sec_per_km') continue; // 반복 횟수·최고 페이스는 차트에서 뺌 (데이터는 기록에 남김)
      const pts = groupByDate(recs, k);
      if (!pts.length) continue;
      const last = pts[pts.length - 1].y;
      const fmt = v => fmtValue(k, v);
      html += card(label(k), lineChart(pts, fmt, { fromZero: !k.includes('pace'), invert: k.includes('pace') }), `최근 ${fmt(last)}`);
    }
    if (!keys.length) html += card('운동 횟수', barChart(groupByDate(recs, '__count').map(p => ({ label: p.x, value: p.y })), v => v + '회', { dateLabels: true }));
  }

  html += card('기록 목록', recs.length ? `<div class="rows">${recs.map(r => `
    <button class="row" data-edit="${r.id}">
      <span class="row-date">${esc(r.date.slice(5).replace('-', '/'))}</span>
      <span class="row-main"><b>${esc(r.exercise_type)}${r.exercise_name ? ' · ' + esc(r.exercise_name) : ''}</b>
        <span>${esc(r.result_summary || '')}${r.duration_min ? ` · ${r.duration_min}분` : ''}</span>
        ${r.memo ? `<em>${esc(r.memo)}</em>` : ''}</span>
    </button>`).join('')}</div>` : '<div class="empty">선택한 조건에 기록이 없어요</div>', '눌러서 수정');

  el.innerHTML = html;
  bind(el, all, today, onEdit);
}

function bind(el, all, today, onEdit) {
  el.querySelectorAll('[data-slicer]').forEach(b => {
    const ev = b.tagName === 'SELECT' ? 'change' : 'click';
    b.addEventListener(ev, () => {
      const k = b.dataset.slicer, v = b.tagName === 'SELECT' ? b.value : b.dataset.value;
      slicer[k] = v;
      if (k === 'type') slicer.name = '';
      renderDashboard(el, all, today, onEdit);
    });
  });
  el.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => onEdit(Number(b.dataset.edit))));
}
