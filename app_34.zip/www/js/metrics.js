// detail_json → 숫자 지표로 자동 펼치기 (대시보드용)
// 규칙
//  - 숫자 값            → 그대로 지표 (distance_km, pace_sec_per_km ...)
//  - 숫자만 담은 객체   → 하위키별 지표 + 합계 (problems.blue, problems.red, problems 합계)
//  - 객체 배열 (sets)   → 개수, 하위 숫자 합계/최대, weight×reps 이면 볼륨
//  - 문자/불리언        → 지표 아님 (슬라이서·표에서만 사용)

const LABELS = {
  duration_min: '운동시간(분)',
  distance_km: '거리(km)',
  pace_sec_per_km: '페이스(/km)',
  avg_heart_rate: '평균 심박',
  max_heart_rate: '최대 심박',
  cadence: '케이던스',
  weight_kg: '무게(kg)',
  sets_count: '세트 수',
  'sets.reps_sum': '총 반복수',
  'sets.weight_kg_max': '최대 무게(kg)',
  volume_kg: '볼륨(kg×회)',
  problems_total: '완등 문제 수',
  calories: '칼로리(kcal)',
  run_avg_pace_sec_per_km: '뛰기 구간 페이스(/km)',
  walk_avg_pace_sec_per_km: '걷기 구간 페이스(/km)',
  best_pace_sec_per_km: '최고 페이스(/km)',
  interval_runs: '빠른 구간 횟수',
  fails: '실패(✕)',
};

const SEG = { run: '뛰기', walk: '걷기' };
const COLORS = { white: '흰색', yellow: '노랑', orange: '주황', green: '초록', blue: '파랑', red: '빨강', purple: '보라',
  pink: '분홍', navy: '남색', gray: '회색', grey: '회색', brown: '갈색', black: '검정', sky: '하늘' };

// 홀드 색깔 → 선 색 (흰색은 진짜 흰색 + 테두리, 검정은 어두운 배경에서도 보이게 조정)
const HOLD_HEX = { white: '#ffffff', yellow: '#eab308', orange: '#f97316', green: '#16a34a', blue: '#2563eb', red: '#dc2626',
  purple: '#9333ea', pink: '#ec4899', navy: '#1e3a8a', gray: '#9ca3af', grey: '#9ca3af', brown: '#92400e', black: '#52525b', sky: '#38bdf8' };
const FALLBACK = ['#0f766e', '#f97316', '#6366f1', '#e11d48', '#65a30d', '#0891b2', '#a855f7', '#ca8a04'];
export function seriesColor(sub, i) { return sub === 'run' ? '#0f766e' : sub === 'walk' ? '#f59e0b' : HOLD_HEX[sub] || FALLBACK[i % FALLBACK.length]; }
export function subLabel(sub) { return SEG[sub] || COLORS[sub] || sub; }

export function label(key) {
  if (LABELS[key]) return LABELS[key];
  if (key.startsWith('problems.')) { const c = key.slice(9); return `${COLORS[c] || c} 문제`; }
  return key.replace(/_/g, ' ');
}

// 평균으로 합쳐야 하는 지표 (같은 날 여러 기록일 때)
export function aggKind(key) {
  return /pace|heart|rate|cadence|weight|_max|avg|segdist/.test(key) ? 'avg' : 'sum';
}

const isNum = v => typeof v === 'number' && isFinite(v);

// 구간 목록: 예전 형식 intervals(type: run/walk/rest) 또는 지금 AI 형식 segments(kind: work/rest)
// segments 는 work → run, rest → walk 로 맞춰서 같은 방식으로 요약한다
function segList(d) {
  const src = Array.isArray(d.intervals) ? d.intervals
    : Array.isArray(d.segments) ? d.segments.map(x => x && ({ ...x, type: x.type || (x.kind === 'rest' ? 'walk' : 'run') }))
    : null;
  return src ? src.filter(x => x && isNum(x.pace_sec_per_km)) : null;
}

export function extractMetrics(rec) {
  const m = {};
  if (isNum(rec.duration_min)) m.duration_min = rec.duration_min;
  const d = rec.detail || {};
  const iv = segList(d);
  for (const [k, v] of Object.entries(d)) {
    if (k === 'duration_min' || k === 'intervals' || k === 'laps' || k === 'segments' || k === '_chart') continue; // 구간 목록은 아래에서 따로 요약
    if (iv && iv.length && k === 'pace_sec_per_km') continue; // 인터벌의 전체 평균 페이스는 걷기가 섞여 추세를 흐림 → 차트 제외
    if (isNum(v)) { m[k] = v; continue; }
    if (v && typeof v === 'object' && !Array.isArray(v)) {
      const nums = Object.entries(v).filter(([, x]) => isNum(x));
      if (nums.length) {
        let tot = 0;
        for (const [sk, sv] of nums) { m[`${k}.${sk}`] = sv; tot += sv; }
        m[`${k}_total`] = tot;
      }
      continue;
    }
    if (Array.isArray(v) && v.length && typeof v[0] === 'object') {
      m[`${k}_count`] = v.length;
      const sub = {};
      for (const it of v) for (const [sk, sv] of Object.entries(it || {})) if (isNum(sv)) (sub[sk] ||= []).push(sv);
      for (const [sk, arr] of Object.entries(sub)) {
        m[`${k}.${sk}_sum`] = arr.reduce((a, b) => a + b, 0);
        m[`${k}.${sk}_max`] = Math.max(...arr);
      }
      // 볼륨 = Σ(세트 무게 × 횟수). 세트에 무게가 없으면 상위 weight_kg 사용
      const topW = isNum(d.weight_kg) ? d.weight_kg : null;
      let vol = 0, ok = false;
      for (const it of v) {
        const w = isNum(it?.weight_kg) ? it.weight_kg : topW;
        if (w != null && isNum(it?.reps)) { vol += w * it.reps; ok = true; }
      }
      if (ok) m.volume_kg = vol;
    }
  }
  // 인터벌: 빠른 구간 요약 (AI가 안 넣었으면 구간 목록에서 계산, 거리 가중 평균)
  if (iv && iv.length) {
    const runs = iv.filter(x => x.type !== 'rest' && x.type !== 'walk');
    if (runs.length) {
      if (!isNum(m.interval_runs)) m.interval_runs = runs.length;
      if (!isNum(m.run_avg_pace_sec_per_km)) {
        const w = runs.reduce((a, x) => a + (isNum(x.distance_km) ? x.distance_km : 0), 0);
        m.run_avg_pace_sec_per_km = w > 0 ? runs.reduce((a, x) => a + x.pace_sec_per_km * (isNum(x.distance_km) ? x.distance_km : 0), 0) / w
          : runs.reduce((a, x) => a + x.pace_sec_per_km, 0) / runs.length;
      }
      if (!isNum(m.best_pace_sec_per_km)) m.best_pace_sec_per_km = Math.min(...runs.map(x => x.pace_sec_per_km));
    }
    // 뛰기/걷기를 따로: 구간 페이스(거리 가중 평균)와 구간 거리 합계
    const wpace = arr => {
      const w = arr.reduce((a, x) => a + (isNum(x.distance_km) ? x.distance_km : 0), 0);
      return w > 0 ? arr.reduce((a, x) => a + x.pace_sec_per_km * (isNum(x.distance_km) ? x.distance_km : 0), 0) / w
        : arr.reduce((a, x) => a + x.pace_sec_per_km, 0) / arr.length;
    };
    const walks = iv.filter(x => x.type === 'rest' || x.type === 'walk');
    if (walks.length) m.walk_avg_pace_sec_per_km = wpace(walks);
    // 구간 1개당 평균 거리 (거리가 적힌 구간만)
    const davg = arr => { const d = arr.filter(x => isNum(x.distance_km)).map(x => x.distance_km); return d.length ? d.reduce((a, b) => a + b, 0) / d.length : null; };
    const ra = davg(runs), wa = davg(walks);
    if (ra != null) m['segdist.run'] = ra;
    if (wa != null) m['segdist.walk'] = wa;
  }
  return m;
}

// 인터벌 구간 목록 (대시보드 구간별 페이스 카드용)
export function intervalsOf(rec) {
  return segList(rec.detail || {}) || [];
}

// 지표 키 정렬: 운동시간 → 인터벌 대표 지표 → 나머지는 등장 빈도 순
const rank = k => ({ duration_min: 0, run_avg_pace_sec_per_km: 1, walk_avg_pace_sec_per_km: 2, best_pace_sec_per_km: 3, interval_runs: 4 }[k] ?? 9);
export function metricKeys(records) {
  const cnt = {};
  for (const r of records) for (const k of Object.keys(extractMetrics(r))) cnt[k] = (cnt[k] || 0) + 1;
  return Object.keys(cnt)
    .filter(k => !k.endsWith('_sum') || k === 'sets.reps_sum')
    .sort((a, b) => rank(a) - rank(b) || cnt[b] - cnt[a]);
}

export function fmtPace(sec) {
  const s = Math.round(sec);
  return `${Math.floor(s / 60)}'${String(s % 60).padStart(2, '0')}"`;
}

export function fmtValue(key, v) {
  if (v == null || !isFinite(v)) return '-';
  if (key.includes('pace')) return fmtPace(v);
  if (key === 'duration_min') return Math.round(v) + '분';
  return Number.isInteger(v) ? v.toLocaleString() : v.toFixed(1);
}
