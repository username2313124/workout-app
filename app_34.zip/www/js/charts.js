// 외부 라이브러리 없이 SVG로 그리는 간단한 차트

const W = 340, H = 170, P = { l: 38, r: 10, t: 12, b: 26 };

function niceMax(v) {
  if (v <= 0) return 1;
  const p = Math.pow(10, Math.floor(Math.log10(v)));
  for (const m of [1, 2, 2.5, 5, 10]) if (v <= m * p) return m * p;
  return 10 * p;
}

const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const shortDate = d => d.slice(5).replace('-', '/');

function frame(maxV, fmt, minV = 0, invert = false) {
  const ih = H - P.t - P.b;
  let s = '';
  for (let i = 0; i <= 3; i++) {
    const v = minV + ((maxV - minV) * i) / 3;
    const y = invert ? P.t + (ih * i) / 3 : P.t + ih - (ih * i) / 3; // invert: 작은 값이 위
    s += `<line x1="${P.l}" x2="${W - P.r}" y1="${y}" y2="${y}" class="grid"/>`;
    s += `<text x="${P.l - 5}" y="${y + 3}" class="ax" text-anchor="end">${esc(fmt(v))}</text>`;
  }
  return s;
}

function xLabels(labels, xAt) {
  const n = labels.length, step = Math.max(1, Math.ceil(n / 5));
  let s = '';
  labels.forEach((l, i) => {
    if ((i % step === 0 && (n - 1 - i >= step * 0.6 || i === 0)) || i === n - 1) { const a = n > 1 && i === n - 1 ? 'end' : n > 1 && i === 0 ? 'start' : 'middle';
      s += `<text x="${xAt(i) + (a === 'end' ? 4 : a === 'start' ? -4 : 0)}" y="${H - 8}" class="ax" text-anchor="${a}">${esc(l)}</text>`; }
  });
  return s;
}

// points: [{x: 'YYYY-MM-DD', y: number}]
export function lineChart(points, fmt = v => v, opts = {}) {
  if (!points.length) return '<div class="empty">데이터 없음</div>';
  const ys = points.map(p => p.y);
  let lo = Math.min(...ys), hi = Math.max(...ys);
  if (opts.fromZero !== false && lo >= 0 && lo / (hi || 1) < 0.5) lo = 0;
  if (hi === lo) { if (hi > 0) { lo = 0; hi = hi * 1.5; } else { hi = hi + 1; lo = Math.max(0, lo - 1); } }
  const pad = (hi - lo) * 0.1; hi += pad; if (lo > 0) lo = Math.max(0, lo - pad);
  const iw = W - P.l - P.r, ih = H - P.t - P.b;
  const xAt = i => P.l + (points.length === 1 ? iw / 2 : (iw * i) / (points.length - 1));
  // invert: 작은 값을 위로 (페이스처럼 낮을수록 좋은 지표)
  const yAt = opts.invert ? v => P.t + (ih * (v - lo)) / (hi - lo) : v => P.t + ih - (ih * (v - lo)) / (hi - lo);
  const path = points.map((p, i) => `${i ? 'L' : 'M'}${xAt(i).toFixed(1)},${yAt(p.y).toFixed(1)}`).join('');
  const dots = points.map((p, i) =>
    `<circle cx="${xAt(i)}" cy="${yAt(p.y)}" r="3" class="dot"><title>${esc(p.x)}: ${esc(fmt(p.y))}</title></circle>`).join('');
  return `<svg viewBox="0 0 ${W} ${H}" class="chart">${frame(hi, fmt, lo, !!opts.invert)}
    <path d="${path}" class="line"/>${dots}${xLabels(points.map(p => shortDate(p.x)), xAt)}</svg>`;
}

const isWhite = c => /^#?f{3}(f{3})?$/i.test(c);

// 여러 선을 한 차트에 겹쳐 그리기 (클라이밍 색깔별 완등 수 등)
// series: [{name, color, points: [{x, y}]}]  — x는 'YYYY-MM-DD'
export function multiLineChart(series, fmt = v => v, { integer = true } = {}) {
  series = series.filter(s => s.points.length);
  if (!series.length) return '<div class="empty">데이터 없음</div>';
  const xs = [...new Set(series.flatMap(s => s.points.map(p => p.x)))].sort();
  const all = series.flatMap(s => s.points.map(p => p.y));
  const lo = 0;
  const mx = Math.max(...all) * 1.1;
  // 눈금 3칸이 깔끔한 숫자로 떨어지게: 개수 지표는 정수(3의 배수), 소수 지표는 0.3·0.6·0.9처럼
  const unit = integer ? 1 : Math.pow(10, Math.floor(Math.log10(Math.max(mx, 1e-9) / 3)));
  const hi = integer ? Math.max(3, Math.ceil(mx / 3) * 3) : Math.max(3 * unit, Math.ceil(mx / (3 * unit)) * 3 * unit);
  const iw = W - P.l - P.r, ih = H - P.t - P.b;
  const xAt = i => P.l + (xs.length === 1 ? iw / 2 : (iw * i) / (xs.length - 1));
  const yAt = v => P.t + ih - (ih * (v - lo)) / (hi - lo);
  const idx = Object.fromEntries(xs.map((x, i) => [x, i]));
  const lines = series.map(s => {
    const pts = s.points.slice().sort((a, b) => a.x.localeCompare(b.x));
    const d = pts.map((p, i) => `${i ? 'L' : 'M'}${xAt(idx[p.x]).toFixed(1)},${yAt(p.y).toFixed(1)}`).join('');
    const dots = pts.map(p => `<circle cx="${xAt(idx[p.x])}" cy="${yAt(p.y)}" r="3" class="dot" style="${isWhite(s.color) ? 'fill:#fff;stroke:#6b7280' : 'stroke:' + s.color}">
      <title>${esc(s.name)} · ${esc(p.x)}: ${esc(fmt(p.y))}</title></circle>`).join('');
    // 흰색 선은 밝은 배경에서 안 보이므로 진한 테두리를 깔고 그 위에 흰 선을 그린다
    const halo = isWhite(s.color) ? `<path d="${d}" class="line" style="stroke:#6b7280;stroke-width:4.5"/>` : '';
    return `${halo}<path d="${d}" class="line" style="stroke:${s.color}"/>${dots}`;
  }).join('');
  const legend = `<div class="legend">${series.map(s =>
    `<span><i style="background:${s.color}${isWhite(s.color) ? ';box-shadow:0 0 0 1px #6b7280' : ''}"></i>${esc(s.name)}</span>`).join('')}</div>`;
  return `<svg viewBox="0 0 ${W} ${H}" class="chart">${frame(hi, fmt, lo)}${lines}${xLabels(xs.map(shortDate), xAt)}</svg>${legend}`;
}

// bars: [{label, value}]
export function barChart(bars, fmt = v => v, { dateLabels = false, integer = false } = {}) {
  if (!bars.length) return '<div class="empty">데이터 없음</div>';
  const mx = Math.max(...bars.map(b => b.value));
  const hi = integer ? Math.max(3, Math.ceil(mx / 3) * 3) : niceMax(mx); // 정수 지표는 눈금이 정수로
  const iw = W - P.l - P.r, ih = H - P.t - P.b;
  const bw = iw / bars.length;
  const xAt = i => P.l + bw * i + bw / 2;
  const rects = bars.map((b, i) => {
    const h = (ih * b.value) / hi;
    const w = Math.max(2, Math.min(28, bw * 0.7));
    return `<rect x="${xAt(i) - w / 2}" y="${P.t + ih - h}" width="${w}" height="${h}" rx="2" class="bar">
      <title>${esc(b.label)}: ${esc(fmt(b.value))}</title></rect>`;
  }).join('');
  const labels = bars.map(b => (dateLabels ? shortDate(b.label) : b.label));
  return `<svg viewBox="0 0 ${W} ${H}" class="chart">${frame(hi, fmt)}${rects}${xLabels(labels, xAt)}</svg>`;
}

// 인터벌 구간별 페이스: 막대 길이 = 속도 (빠를수록 길게), 빠른 구간/회복 구간 색 구분
export function intervalBars(segs, fmtPace) {
  if (!segs.length) return '<div class="empty">구간 기록 없음</div>';
  const speeds = segs.map(x => 3600 / x.pace_sec_per_km); // km/h
  const hi = Math.max(...speeds);
  let run = 0;
  return `<div class="hbars iv">${segs.map((x, i) => {
    const isRun = x.type !== 'rest' && x.type !== 'walk'; if (isRun) run++;
    const name = isRun ? `${run}번째 뛰기` : '걷기';
    const dist = typeof x.distance_km === 'number' ? ` ${x.distance_km < 1 ? Math.round(x.distance_km * 1000) + 'm' : x.distance_km.toFixed(2) + 'km'}` : '';
    return `<div class="hbar-row ${isRun ? '' : 'rest'}"><span class="hbar-label">${esc(name + dist)}</span>
      <span class="hbar-track"><span class="hbar-fill" style="width:${(100 * speeds[i] / hi).toFixed(1)}%"></span></span>
      <span class="hbar-val">${esc(fmtPace(x.pace_sec_per_km))}</span></div>`;
  }).join('')}</div>`;
}

// 가로 막대 (종류별 비교)
export function hBarChart(bars, fmt = v => v) {
  if (!bars.length) return '<div class="empty">데이터 없음</div>';
  const hi = Math.max(...bars.map(b => b.value)) || 1;
  return `<div class="hbars">${bars.map(b => `
    <div class="hbar-row"><span class="hbar-label">${esc(b.label)}</span>
      <span class="hbar-track"><span class="hbar-fill" style="width:${(100 * b.value / hi).toFixed(1)}%"></span></span>
      <span class="hbar-val">${esc(fmt(b.value))}</span></div>`).join('')}</div>`;
}
