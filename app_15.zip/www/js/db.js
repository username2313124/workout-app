// 폰 내부 저장소.
// - 앱(Android/iOS)에서는 SQLite 테이블 workout_logs 사용
// - 브라우저 미리보기에서는 localStorage로 대체 (테스트용)

const DB_NAME = 'workoutlog';

const SCHEMA = `
CREATE TABLE IF NOT EXISTS workout_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date TEXT NOT NULL,
  exercise_type TEXT NOT NULL,
  exercise_name TEXT,
  duration_min REAL,
  result_summary TEXT,
  detail_json TEXT,
  memo TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_logs_date ON workout_logs(date);
CREATE INDEX IF NOT EXISTS idx_logs_type ON workout_logs(exercise_type);
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT
);
`;

const nowIso = () => new Date().toISOString();

function isNative() {
  return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
}

function parseRow(r) {
  let detail = {};
  try { detail = r.detail_json ? JSON.parse(r.detail_json) : {}; } catch { detail = {}; }
  return { ...r, detail };
}

/* ---------- SQLite (앱) ---------- */
class SqliteStore {
  async init() {
    this.p = window.Capacitor.registerPlugin('CapacitorSQLite');
    try {
      await this.p.createConnection({ database: DB_NAME, version: 1, encrypted: false, mode: 'no-encryption', readonly: false });
    } catch (e) { /* 이미 연결된 경우 */ }
    await this.p.open({ database: DB_NAME, readonly: false });
    await this.p.execute({ database: DB_NAME, statements: SCHEMA, transaction: true, readonly: false });
  }
  async q(statement, values = []) {
    const res = await this.p.query({ database: DB_NAME, statement, values, readonly: false });
    return res.values || [];
  }
  async run(statement, values = []) {
    const res = await this.p.run({ database: DB_NAME, statement, values, transaction: true, readonly: false });
    return res.changes || {};
  }
  async all() {
    return (await this.q('SELECT * FROM workout_logs ORDER BY date DESC, id DESC')).map(parseRow);
  }
  async insert(rec) {
    const t = nowIso();
    const ch = await this.run(
      `INSERT INTO workout_logs (date, exercise_type, exercise_name, duration_min, result_summary, detail_json, memo, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,?,?)`,
      [rec.date, rec.exercise_type, rec.exercise_name ?? null, rec.duration_min ?? null, rec.result_summary ?? null,
       JSON.stringify(rec.detail_json || {}), rec.memo ?? null, t, t]
    );
    return ch.lastId;
  }
  async update(id, rec) {
    await this.run(
      `UPDATE workout_logs SET date=?, exercise_type=?, exercise_name=?, duration_min=?, result_summary=?, detail_json=?, memo=?, updated_at=? WHERE id=?`,
      [rec.date, rec.exercise_type, rec.exercise_name ?? null, rec.duration_min ?? null, rec.result_summary ?? null,
       JSON.stringify(rec.detail_json || {}), rec.memo ?? null, nowIso(), id]
    );
  }
  async remove(id) { await this.run('DELETE FROM workout_logs WHERE id=?', [id]); }
  async clear() { await this.run('DELETE FROM workout_logs'); }
  // 종목 목록 = 기록에 있는 exercise_type 값 (별도 테이블 없음)
  async types() {
    return (await this.q('SELECT DISTINCT exercise_type AS name FROM workout_logs')).map(r => r.name);
  }
  async getSetting(key) {
    const r = await this.q('SELECT value FROM settings WHERE key=?', [key]);
    return r.length ? r[0].value : null;
  }
  async setSetting(key, value) {
    await this.run('INSERT OR REPLACE INTO settings (key, value) VALUES (?,?)', [key, value]);
  }
}

/* ---------- localStorage (브라우저 미리보기) ---------- */
class LocalStore {
  _get(k, d) { try { return JSON.parse(localStorage.getItem('wl_' + k)) ?? d; } catch { return d; } }
  _set(k, v) { try { localStorage.setItem('wl_' + k, JSON.stringify(v)); } catch {} }
  async init() {
    // 기기 저장 공간을 지우지 않도록 요청 (홈 화면 앱/크롬)
    try { await navigator.storage?.persist?.(); } catch {}
  }
  async all() {
    return this._get('logs', []).slice().sort((a, b) => (b.date.localeCompare(a.date)) || (b.id - a.id)).map(parseRow);
  }
  async insert(rec) {
    const logs = this._get('logs', []);
    const id = (logs.reduce((m, r) => Math.max(m, r.id), 0)) + 1;
    const t = nowIso();
    logs.push({ id, date: rec.date, exercise_type: rec.exercise_type, exercise_name: rec.exercise_name ?? null,
      duration_min: rec.duration_min ?? null, result_summary: rec.result_summary ?? null,
      detail_json: JSON.stringify(rec.detail_json || {}), memo: rec.memo ?? null, created_at: t, updated_at: t });
    this._set('logs', logs);
    return id;
  }
  async update(id, rec) {
    const logs = this._get('logs', []);
    const i = logs.findIndex(r => r.id === id);
    if (i < 0) return;
    logs[i] = { ...logs[i], date: rec.date, exercise_type: rec.exercise_type, exercise_name: rec.exercise_name ?? null,
      duration_min: rec.duration_min ?? null, result_summary: rec.result_summary ?? null,
      detail_json: JSON.stringify(rec.detail_json || {}), memo: rec.memo ?? null, updated_at: nowIso() };
    this._set('logs', logs);
  }
  async remove(id) { this._set('logs', this._get('logs', []).filter(r => r.id !== id)); }
  async clear() { this._set('logs', []); }
  async types() { return [...new Set(this._get('logs', []).map(r => r.exercise_type))]; }
  async getSetting(key) { return this._get('set_' + key, null); }
  async setSetting(key, value) { this._set('set_' + key, value); }
}

// 앱에서 SQLite가 안 열리면(일부 기종·버전) 멈추지 말고 기기 내 저장소(localStorage)로 대신 쓴다
const withTimeout = (p, ms) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('SQLite 응답 없음')), ms))]);
class SafeStore {
  constructor() { this.s = isNative() ? new SqliteStore() : new LocalStore(); this.fallback = false; }
  async init() {
    try { await withTimeout(this.s.init(), 5000); }
    catch (e) {
      console.warn('SQLite 사용 불가, localStorage로 대체:', e);
      this.s = new LocalStore(); this.fallback = true; this.initError = e?.message || String(e);
      await this.s.init();
    }
  }
}
for (const m of ['all', 'insert', 'update', 'remove', 'clear', 'types', 'getSetting', 'setSetting'])
  SafeStore.prototype[m] = function (...a) { return this.s[m](...a); };

export const db = new SafeStore();
export { isNative };
