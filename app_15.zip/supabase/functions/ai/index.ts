// 운동기록 앱 → OpenRouter 중계 함수
// 필요한 비밀값(Edge Functions → Secrets): OPENROUTER_API_KEY
// 선택: DAILY_LIMIT (기본 10), AI_MODELS (쉼표로 구분, 앞에서부터 시도. 비우면 openrouter/free = 무료 모델만)
import { createClient } from 'npm:@supabase/supabase-js@2';

const DAILY_LIMIT = Number(Deno.env.get('DAILY_LIMIT') ?? '10');
const MODELS = (Deno.env.get('AI_MODELS') || 'openrouter/free')
  .split(',').map(s => s.trim()).filter(Boolean);
const MAX_IMAGES = 4;
const MAX_BODY = 8 * 1024 * 1024; // 8MB

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });
const fail = (status: number, message: string, extra = {}) => json({ error: { message }, ...extra }, status);

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return fail(405, 'POST만 받아요');

  const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

  // 1) 누가 보냈는지 확인 (익명 로그인 토큰)
  const token = (req.headers.get('Authorization') ?? '').replace(/^Bearer\s+/i, '');
  const { data: { user } } = await admin.auth.getUser(token);
  if (!user) return fail(401, '로그인이 필요해요');

  // 2) 요청 크기·사진 장수 확인
  const raw = await req.text();
  if (raw.length > MAX_BODY) return fail(413, '사진이 너무 커요');
  let body: any;
  try { body = JSON.parse(raw); } catch { return fail(400, '잘못된 요청이에요'); }
  if (!Array.isArray(body?.messages)) return fail(400, 'messages가 필요해요');
  const images = body.messages.flatMap((m: any) => Array.isArray(m.content) ? m.content : [])
    .filter((c: any) => c?.type === 'image_url').length;
  if (images > MAX_IMAGES) return fail(400, `사진은 한 번에 ${MAX_IMAGES}장까지예요`);

  // 3) 하루 한도 차감
  const { data: used, error: qErr } = await admin.rpc('use_ai_quota', { p_user: user.id, p_limit: DAILY_LIMIT });
  if (qErr) return fail(500, '사용량 확인 실패: ' + qErr.message);
  if (used === null) return fail(429, `free-models-per-day: 오늘 쓸 수 있는 ${DAILY_LIMIT}회를 다 썼어요. 내일 0시에 다시 차요.`, { remaining: 0 });

  // 4) 모델을 앞에서부터 시도 (혼잡·오류면 다음 모델)
  let lastStatus = 0, lastMsg = '';
  for (const model of MODELS) {
    const call = (jsonMode: boolean) => fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${Deno.env.get('OPENROUTER_API_KEY')}`,
        'Content-Type': 'application/json',
        'X-Title': 'Caldron AI',
      },
      body: JSON.stringify({
        model, messages: body.messages,
        ...(jsonMode ? { response_format: { type: 'json_object' } } : {}),
      }),
    });
    let res = await call(body.json !== false);
    if (res.status === 400 && body.json !== false) res = await call(false); // JSON 모드 미지원 모델

    const data = await res.json().catch(() => ({}));
    await admin.from('ai_logs').insert({
      user_id: user.id, model, status: res.status,
      prompt_tokens: data?.usage?.prompt_tokens ?? null,
      completion_tokens: data?.usage?.completion_tokens ?? null,
      cost: data?.usage?.cost ?? null,
    });
    if (res.ok && !data.error) return json({ ...data, remaining: DAILY_LIMIT - used });
    lastStatus = res.status; lastMsg = data?.error?.message ?? `HTTP ${res.status}`;
    if (res.status === 400 || res.status === 401) break; // 요청 자체 문제는 다른 모델로 넘어가도 같음
  }

  // 5) 전부 실패 → 차감한 1회 돌려주기
  await admin.rpc('refund_ai_quota', { p_user: user.id });
  return fail(lastStatus === 429 ? 503 : 502, 'AI 서버가 응답하지 않아요. 잠시 후 다시 보내 주세요. (' + lastMsg + ')');
});
