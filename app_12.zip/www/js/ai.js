// AI 호출: 사용자의 말/사진을 workout_logs 형식으로 정형화
// OpenAI 와 OpenRouter 둘 다 같은 형식(chat/completions)을 쓴다

import { serverChat } from './server.js';

export const PROVIDERS = {
  server: { label: '기본 (앱 제공, 무료)', base: '', keyPrefix: '', defaultModel: '' },
  openai: {
    label: 'OpenAI (ChatGPT)', base: 'https://api.openai.com/v1', keyPrefix: 'sk-',
    keyUrl: 'platform.openai.com/api-keys', defaultModel: 'gpt-4.1-mini',
  },
  openrouter: {
    label: 'OpenRouter', base: 'https://openrouter.ai/api/v1', keyPrefix: 'sk-or-',
    keyUrl: 'openrouter.ai/keys', defaultModel: '',
  },
};

function headers(provider, apiKey) {
  const h = { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` };
  if (provider === 'openrouter') { h['HTTP-Referer'] = 'https://workoutlog.app'; h['X-Title'] = 'Caldron AI'; }
  return h;
}

export async function validateKey(provider, apiKey) {
  const p = PROVIDERS[provider];
  const url = provider === 'openrouter' ? `${p.base}/key` : `${p.base}/models`;
  const res = await fetch(url, { headers: headers(provider, apiKey) });
  if (res.status === 401 || res.status === 403) throw new Error('API 키가 올바르지 않습니다.');
  if (!res.ok) throw new Error(`확인 실패 (HTTP ${res.status})`);
  return true;
}

export function usableModelId(id) {
  const tag = String(id || '').split(':')[1];
  return !tag || tag === 'free';
}

// OpenRouter: 사진을 읽을 수 있는 모델 목록 (가격 포함)
export async function listVisionModels() {
  const res = await fetch(`${PROVIDERS.openrouter.base}/models`);
  if (!res.ok) throw new Error(`모델 목록을 못 받았어요 (HTTP ${res.status})`);
  const { data = [] } = await res.json();
  return data
    // 일반 대화(chat/completions)로 쓸 수 없는 변형(:batch 등)은 뺀다. :free 는 남김
    .filter(m => usableModelId(m.id))
    .filter(m => (m.architecture?.input_modalities || []).includes('image') && (m.architecture?.output_modalities || ['text']).includes('text'))
    .map(m => {
      const inP = Number(m.pricing?.prompt || 0) * 1e6, outP = Number(m.pricing?.completion || 0) * 1e6;
      return { id: m.id, name: m.name || m.id, free: inP === 0 && outP === 0, inP, outP };
    })
    .sort((x, y) => (x.free === y.free ? x.inP - y.inP : x.free ? -1 : 1));
}

// 기본 모델 고르기: 사진 잘 읽고 저렴한 계열 우선, 없으면 가장 싼 유료 모델
export function pickDefaultModel(models) {
  const paid = models.filter(m => !m.free);
  for (const re of [/gemini.*flash(?!.*lite)/i, /gpt.*mini/i, /claude.*haiku/i, /gemini/i]) {
    const hit = paid.find(m => re.test(m.id));
    if (hit) return hit.id;
  }
  return (paid[0] || models[0] || {}).id || '';
}

function systemPrompt({ today, types, names }) {
  return `너는 운동 기록 앱의 기록 도우미다. 사용자의 말에서 운동 기록을 추출해 JSON으로만 답한다.
오늘 날짜: ${today} (Asia/Seoul). "어제", "지난 토요일" 같은 표현은 이 날짜 기준으로 계산한다.

[기존 운동종류(exercise_type)] ${types.length ? types.join(', ') : '(아직 없음)'}
[기존 세부운동(exercise_name)] ${names.length ? names.join(', ') : '(아직 없음)'}

규칙
- 가능한 한 기존 운동종류/세부운동 이름을 그대로 재사용한다. 표기만 다른 경우(예: 런닝→러닝) 기존 이름으로 맞춘다.
- 기존 운동종류에 맞지 않으면 새 운동종류 이름을 짧게 정하고 is_new_type=true 로 표시하며, 가장 가까운 기존 종류를 candidates 에 최대 3개 넣는다.
- 헬스처럼 한 번에 여러 세부운동을 하면 세부운동마다 records 하나씩 만든다.
- 클라이밍의 exercise_name 은 지점·지역명을 뺀 암장 브랜드 이름으로 한다 (예: "더클라임 성수점" → "더클라임", "알레클라임 혜화" → "알레클라임"). 기존 세부운동에 같은 암장이 있으면 그 이름을 그대로 쓴다. 지점까지 포함한 전체 이름은 detail_json.gym 에 넣는다.
- duration_min 은 분 단위 숫자. 모르면 null.
- result_summary 는 대표 결과를 20자 이내로 직접 만든다 (예: "5km 무휴식", "20kg 6/5/4회", "파랑4 빨강2").
- memo 는 사용자의 느낌/컨디션 표현만 담는다. 없으면 null.
- detail_json 은 종목별 세부정보. 숫자는 숫자 타입으로, 모르는 값은 넣지 않는다. 같은 운동종류는 항상 같은 키 이름을 쓴다.
  러닝 예: {"distance_km":5.0,"pace_sec_per_km":408,"avg_heart_rate":168,"max_heart_rate":181,"cadence":155,"continuous":true}
  헬스 예: {"sets":[{"weight_kg":20,"reps":6},{"weight_kg":20,"reps":5}],"assistance":null}
  클라이밍 예: {"gym":"더클라임 성수","problems":{"blue":4,"red":2}} (exercise_name 은 "더클라임")
  새 종목은 위 예시처럼 숫자로 비교 가능한 키(영문 snake_case)를 만든다.
- 페이스 "6분48초" → 408 처럼 초로 변환한다.
- 사진이 첨부되면 러닝앱(나이키런, 스트라바, 가민, 애플워치 등)이나 클라이밍 앱/기록 공유 이미지다. 사진에 보이는 숫자를 그대로 읽어 기록한다:
  거리, 시간, 평균 페이스, 심박(평균/최대), 케이던스, 고도(elevation_gain_m), 칼로리(calories), 날짜, 장소/암장 이름, 난이도 색깔·그레이드별 완등 수 등.
  사진에 날짜가 보이면 그 날짜를 쓰고, 없으면 오늘로 한다. 시간 "34:12" 는 34.2분. 잘 안 보이는 값은 지어내지 말고 넣지 않는다.
  여러 장이면 같은 운동이면 합치고, 다른 운동이면 각각 records 로 만든다.
  reply 에는 사진에서 읽은 핵심 수치를 한 줄로 요약한다.
- 운동 기록이 아닌 말이면 intent="other", 운동 이야기지만 정보가 부족하면 intent="clarify" 로 하고 reply 에 짧게 되묻는다.
  (종목과 날짜만 알면 기록 가능. 나머지는 없어도 된다.)

출력 형식 (JSON만):
{
  "intent": "log" | "clarify" | "other",
  "reply": "사용자에게 보여줄 짧은 한국어 문장",
  "records": [
    {
      "date": "YYYY-MM-DD",
      "exercise_type": "러닝",
      "is_new_type": false,
      "candidates": [],
      "exercise_name": "야외 러닝",
      "duration_min": 34,
      "result_summary": "5km 무휴식",
      "detail_json": {},
      "memo": null
    }
  ]
}`;
}

// 사진 → 긴 변 1600px JPEG data URL (전송량 줄이기)
async function toDataUrl(file) {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((ok, bad) => { const i = new Image(); i.onload = () => ok(i); i.onerror = bad; i.src = url; });
    const scale = Math.min(1, 1600 / Math.max(img.naturalWidth, img.naturalHeight));
    const cv = document.createElement('canvas');
    cv.width = Math.round(img.naturalWidth * scale); cv.height = Math.round(img.naturalHeight * scale);
    cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
    return cv.toDataURL('image/jpeg', 0.85);
  } catch (e) {
    throw new Error('사진을 열 수 없어요. JPG·PNG 사진으로 다시 올려 주세요.' + (e?.message ? ` (${e.message})` : ''));
  } finally { URL.revokeObjectURL(url); }
}

export async function parseWorkout({ provider = 'openai', apiKey, model, history, text, today, types, names, images = [] }) {
  let userContent = text;
  if (images.length) {
    const urls = await Promise.all(images.map(toDataUrl));
    userContent = [{ type: 'text', text }, ...urls.map(u => ({ type: 'image_url', image_url: { url: u, detail: 'high' } }))];
  }
  const messages = [
    { role: 'system', content: systemPrompt({ today, types, names }) },
    ...history.slice(-8),
    { role: 'user', content: userContent },
  ];
  if (provider === 'server') {
    const data = await serverChat(messages);
    const out = parseContent(data.choices?.[0]?.message?.content);
    out.remaining = data.remaining;
    return out;
  }
  if (!model) throw new Error('설정 탭에서 모델을 먼저 골라 주세요.');
  const url = `${PROVIDERS[provider].base}/chat/completions`;
  const call = jsonMode => fetch(url, {
    method: 'POST', headers: headers(provider, apiKey),
    body: JSON.stringify({ model, messages, ...(jsonMode ? { response_format: { type: 'json_object' } } : {}) }),
  });
  let res = await call(true);
  if (res.status === 400) res = await call(false); // JSON 모드를 지원하지 않는 모델
  if (!res.ok) {
    let msg = `HTTP ${res.status}`;
    try { const j = await res.json(); msg = j.error?.message || msg; } catch {}
    if (res.status === 402) msg = '크레딧이 부족해요. 충전하거나 무료 모델을 골라 주세요.';
    if (res.status === 429) {
      const raw = msg;
      if (/per-day|per day/i.test(raw)) msg = '오늘 무료 모델 하루 한도를 다 썼어요. 내일 오전 9시에 다시 차요. 그 전에 쓰려면 설정에서 유료 모델로 바꿔 주세요.';
      else if (/per-min|per minute/i.test(raw)) msg = '1분에 보낼 수 있는 횟수를 넘었어요. 1분 뒤에 다시 보내 주세요.';
      else msg = '지금 이 무료 모델을 쓰는 사람이 많아서 막혔어요 (내 한도와는 별개). 잠시 후 다시 보내거나 설정에서 다른 모델로 바꿔 주세요.';
      msg += `\n(원문: ${raw})`;
    }
    throw new Error(msg);
  }
  const data = await res.json();
  if (data.error) throw new Error(data.error.message || '모델 오류');
  return parseContent(data.choices?.[0]?.message?.content);
}

function parseContent(content = '{}') {
  let out;
  try { out = JSON.parse(content || '{}'); }
  catch {
    const m = String(content).match(/\{[\s\S]*\}/); // 앞뒤 설명이 붙은 경우
    try { out = JSON.parse(m ? m[0] : ''); } catch { throw new Error('응답을 해석하지 못했습니다. 다시 보내 주세요.'); }
  }
  out.records = Array.isArray(out.records) ? out.records : [];
  return out;
}
