# CI에서 실행: resources/icon.png 를 Android/iOS 앱 아이콘으로 복사
import os, shutil
from PIL import Image

root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = Image.open(os.path.join(root, 'resources', 'icon.png')).convert('RGBA')

res = os.path.join(root, 'android', 'app', 'src', 'main', 'res')
if os.path.isdir(res):
    for name, px in {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}.items():
        d = os.path.join(res, f'mipmap-{name}')
        os.makedirs(d, exist_ok=True)
        img = src.resize((px, px), Image.LANCZOS)
        for f in ('ic_launcher.png', 'ic_launcher_round.png'):
            img.save(os.path.join(d, f))
        fg = os.path.join(d, 'ic_launcher_foreground.png')
        if os.path.exists(fg):
            os.remove(fg)
    shutil.rmtree(os.path.join(res, 'mipmap-anydpi-v26'), ignore_errors=True)
    print('android icon applied')

ios = os.path.join(root, 'ios', 'App', 'App', 'Assets.xcassets', 'AppIcon.appiconset')
if os.path.isdir(ios):
    for f in os.listdir(ios):
        if f.endswith('.png'):
            Image.open(os.path.join(root, 'resources', 'icon.png')).convert('RGB').resize((1024, 1024)).save(os.path.join(ios, f))
    print('ios icon applied')
