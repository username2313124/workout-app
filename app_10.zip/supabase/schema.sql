-- 1) 사용자별 하루 사용 횟수
create table if not exists public.ai_usage (
  user_id uuid not null references auth.users(id) on delete cascade,
  day     date not null,
  count   int  not null default 0,
  primary key (user_id, day)
);

-- 2) 호출 기록 (비용 모니터링용)
create table if not exists public.ai_logs (
  id bigint generated always as identity primary key,
  user_id uuid,
  created_at timestamptz not null default now(),
  model text,
  status int,
  prompt_tokens int,
  completion_tokens int,
  cost numeric
);

-- 앱(클라이언트)에서는 두 테이블을 읽거나 쓸 수 없게 잠금. 서버 함수(service role)만 접근
alter table public.ai_usage enable row level security;
alter table public.ai_logs  enable row level security;

-- 3) 한도 안이면 +1 하고 오늘 사용 횟수를 돌려줌. 한도를 넘었으면 null
create or replace function public.use_ai_quota(p_user uuid, p_limit int)
returns int language plpgsql security definer set search_path = public as $$
declare c int;
begin
  insert into ai_usage (user_id, day, count)
  values (p_user, (now() at time zone 'Asia/Seoul')::date, 1)
  on conflict (user_id, day) do update
    set count = ai_usage.count + 1
    where ai_usage.count < p_limit
  returning count into c;
  return c;
end $$;

-- 4) AI 호출이 전부 실패했을 때 1회 돌려주기
create or replace function public.refund_ai_quota(p_user uuid)
returns void language sql security definer set search_path = public as $$
  update ai_usage set count = greatest(count - 1, 0)
  where user_id = p_user and day = (now() at time zone 'Asia/Seoul')::date;
$$;

revoke execute on function public.use_ai_quota(uuid, int) from public, anon, authenticated;
revoke execute on function public.refund_ai_quota(uuid)   from public, anon, authenticated;
grant  execute on function public.use_ai_quota(uuid, int) to service_role;
grant  execute on function public.refund_ai_quota(uuid)   to service_role;
