// Supabase 공개 설정 (앱에 들어가도 되는 공개 값. secret/service_role 키는 절대 넣지 말 것)
export const SUPABASE_URL = 'https://jokepdirwwkcyjtogxfe.supabase.co';
export const SUPABASE_KEY = 'sb_publishable_HtvKtv24zAqHV5Ejv1v_ZQ_EryKs9oa';
