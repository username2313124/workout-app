// detail_json → 숫자 지표로 자동 펼치기 (대시보드용)
// 규칙
//  - 숫자 값            → 그대로 지표 (distance_km, pace_sec_per_km ...)
//  - 숫자만 담은 객체   → 하위키별 지표 + 합계 (problems.blue, problems.red, problems 합계)
//  - 객체 배열 (sets)   → 개수, 하위 숫자 합계/최대, weight×reps 이면 볼륨
//  - 문자/불리언        → 지표 아님 (슬라이서·표에서만 사용)

const LABELS = {
  duration_min: '운동시간(분)',
  distance_km: '거리(km)',
  pace_sec_per_km: '페이스(초/km)',
  avg_heart_rate: '평균 심박',
  max_heart_rate: '최대 심박',
  cadence: '케이던스',
  weight_kg: '무게(kg)',
  sets_count: '세트 수',
  'sets.reps_sum': '총 반복수',
  'sets.weight_kg_max': '최대 무게(kg)',
  volume_kg: '볼륨(kg×회)',
  problems_total: '완등 문제 수',
  fails: '실패(✕)',
};

const COLORS = { white: '흰색', yellow: '노랑', orange: '주황', green: '초록', blue: '파랑', red: '빨강', purple: '보라',
  pink: '분홍', navy: '남색', gray: '회색', grey: '회색', brown: '갈색', black: '검정', sky: '하늘' };

export function label(key) {
  if (LABELS[key]) return LABELS[key];
  if (key.startsWith('problems.')) { const c = key.slice(9); return `${COLORS[c] || c} 문제`; }
  return key.replace(/_/g, ' ');
}

// 평균으로 합쳐야 하는 지표 (같은 날 여러 기록일 때)
export function aggKind(key) {
  return /pace|heart|rate|cadence|weight|_max|avg/.test(key) ? 'avg' : 'sum';
}

const isNum = v => typeof v === 'number' && isFinite(v);

export function extractMetrics(rec) {
  const m = {};
  if (isNum(rec.duration_min)) m.duration_min = rec.duration_min;
  const d = rec.detail || {};
  for (const [k, v] of Object.entries(d)) {
    if (k === 'duration_min') continue;
    if (isNum(v)) { m[k] = v; continue; }
    if (v && typeof v === 'object' && !Array.isArray(v)) {
      const nums = Object.entries(v).filter(([, x]) => isNum(x));
      if (nums.length) {
        let tot = 0;
        for (const [sk, sv] of nums) { m[`${k}.${sk}`] = sv; tot += sv; }
        m[`${k}_total`] = tot;
      }
      continue;
    }
    if (Array.isArray(v) && v.length && typeof v[0] === 'object') {
      m[`${k}_count`] = v.length;
      const sub = {};
      for (const it of v) for (const [sk, sv] of Object.entries(it || {})) if (isNum(sv)) (sub[sk] ||= []).push(sv);
      for (const [sk, arr] of Object.entries(sub)) {
        m[`${k}.${sk}_sum`] = arr.reduce((a, b) => a + b, 0);
        m[`${k}.${sk}_max`] = Math.max(...arr);
      }
      // 볼륨 = Σ(세트 무게 × 횟수). 세트에 무게가 없으면 상위 weight_kg 사용
      const topW = isNum(d.weight_kg) ? d.weight_kg : null;
      let vol = 0, ok = false;
      for (const it of v) {
        const w = isNum(it?.weight_kg) ? it.weight_kg : topW;
        if (w != null && isNum(it?.reps)) { vol += w * it.reps; ok = true; }
      }
      if (ok) m.volume_kg = vol;
    }
  }
  return m;
}

// 지표 키 정렬: 운동시간 먼저, 나머지는 등장 빈도 순
export function metricKeys(records) {
  const cnt = {};
  for (const r of records) for (const k of Object.keys(extractMetrics(r))) cnt[k] = (cnt[k] || 0) + 1;
  return Object.keys(cnt)
    .filter(k => !k.endsWith('_sum') || k === 'sets.reps_sum')
    .sort((a, b) => (a === 'duration_min' ? -1 : b === 'duration_min' ? 1 : cnt[b] - cnt[a]));
}

export function fmtPace(sec) {
  const s = Math.round(sec);
  return `${Math.floor(s / 60)}'${String(s % 60).padStart(2, '0')}"`;
}

export function fmtValue(key, v) {
  if (v == null || !isFinite(v)) return '-';
  if (key.includes('pace')) return fmtPace(v);
  if (key === 'duration_min') return Math.round(v) + '분';
  return Number.isInteger(v) ? v.toLocaleString() : v.toFixed(1);
}
